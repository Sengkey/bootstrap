<?php

class SiteController extends Controller
{
	/**
	 * Declares class-based actions.
	 */
	public function actions()
	{
		return array(
			// captcha action renders the CAPTCHA image displayed on the contact page
			'captcha'=>array(
				'class'=>'CCaptchaAction',
				'backColor'=>0xFFFFFF,
			),
			// page action renders "static" pages stored under 'protected/views/site/pages'
			// They can be accessed via: index.php?r=site/page&view=FileName
			'page'=>array(
				'class'=>'CViewAction',
			),
		);
	}

	/**
	 * This is the default 'index' action that is invoked
	 * when an action is not explicitly requested by users.
	 */
	public function actionIndex()
	{
		$data['tpl'] = "/site/home";
		$data['en-lang'] = "Gereja Indonesia di Sydney";
		$data['en-url'] = "";
		$data['id-lang'] = "Church Sydney";
		$data['id-url'] = "";
		Yii::app()->session['lang'] = 'en';
		$this->render('index',array("data"=>$data));
	}
	public function actionIndo()
	{
		$data['tpl'] = "/site/home";
		Yii::app()->session['lang'] = 'id';
		$this->render('index',array("data"=>$data));
	}
	public function actionIndex1()
	{
		$this->render('index1');
	}

	public function actionVisionMission()
	{
		$data['tpl'] = "en/about/visionmission";
		$data['en-lang'] = "Vision Mission";
		$data['en-url'] = "visionmission";
		$data['id-lang'] = "Visi Misi";
		$data['id-url'] = "visimisi";
		if (Yii::app()->session['lang']=="id") {
			$this->redirect('id/visimisi');
		} else {
			$this->render('index',array("data"=>$data));
		}
	}
	public function actionVisionMissionID()
	{
		$data['tpl'] = "id/tentang/visimisi";
		$data['en-lang'] = "Vision Mission";
		$data['en-url'] = "visionmission";
		$data['id-lang'] = "Visi Misi";
		$data['id-url'] = "visimisi";
		$this->render('index',array("data"=>$data));
	}
	public function actionWhatWeBelieve()
	{
		$data['tpl'] = "en/about/whatwebelieve";
		$data['en-lang'] = "What we believe";
		$data['en-url'] = "whatwebelieve";
		$data['id-lang'] = "Pengakuan Iman";
		$data['id-url'] = "pengakuaniman";
		if (Yii::app()->session['lang']=="id") {
			$this->redirect('id/pengakuaniman');
		} else {
			$this->render('index',array("data"=>$data));
		}
	}
	public function actionWhatWeBelieveID()
	{
		$data['tpl'] = "id/tentang/pengakuaniman";
		$data['en-lang'] = "What we believe";
		$data['en-url'] = "whatwebelieve";
		$data['id-lang'] = "Pengakuan Iman";
		$data['id-url'] = "pengakuaniman";
		$this->render('index',array("data"=>$data));
	}
	public function actionCoreValues()
	{
		$data['tpl'] = "en/about/corevalues";
		$data['en-lang'] = "Core Values";
		$data['en-url'] = "corevalues";
		$data['id-lang'] = "Dasar Pemikiran";
		$data['id-url'] = "dasarpemikiran";
		if (Yii::app()->session['lang']=="id") {
			$this->redirect('id/dasarpemikiran');
		} else {
			$this->render('index',array("data"=>$data));
		}
	}
	public function actionCoreValuesID()
	{
		$data['tpl'] = "id/tentang/dasarpemikiran";
		$data['en-lang'] = "Core Values";
		$data['en-url'] = "corevalues";
		$data['id-lang'] = "Dasar Pemikiran";
		$data['id-url'] = "dasarpemikiran";
		$this->render('index',array("data"=>$data));
	}
	public function actionStrategy()
	{
		$data['tpl'] = "en/about/strategy";
		$data['en-lang'] = "Strategy";
		$data['en-url'] = "strategy";
		$data['id-lang'] = "Strategi";
		$data['id-url'] = "strategi";
		if (Yii::app()->session['lang']=="id") {
			$this->redirect('id/strategi');
		} else {
			$this->render('index',array("data"=>$data));
		}
	}
	public function actionStrategyID()
	{
		$data['tpl'] = "id/tentang/strategi";
		$data['en-lang'] = "Strategy";
		$data['en-url'] = "strategy";
		$data['id-lang'] = "Strategi";
		$data['id-url'] = "strategi";
		$this->render('index',array("data"=>$data));
	}
	public function actionHistory()
	{
		$data['tpl'] = "en/about/history";
		$data['en-lang'] = "History";
		$data['en-url'] = "history";
		$data['id-lang'] = "Sejarah";
		$data['id-url'] = "sejarah";
		if (Yii::app()->session['lang']=="id") {
			$this->redirect('id/sejarah');
		} else {
			$this->render('index',array("data"=>$data));
		}
	}
	public function actionHistoryID()
	{
		$data['tpl'] = "id/tentang/sejarah";
		$data['en-lang'] = "History";
		$data['en-url'] = "history";
		$data['id-lang'] = "Sejarah";
		$data['id-url'] = "sejarah";
		$this->render('index',array("data"=>$data));
	}

	public function actionFoodBeverageMinistry()
	{
		$data['tpl'] = "en/ministry/foodbeverage";
		$data['en-lang'] = "Food &amp; Beverage";
		$data['en-url'] = "foodbeverage";
		$data['id-lang'] = "Makanan &amp; Minuman";
		$data['id-url'] = "makanan-minuman";
		if (Yii::app()->session['lang']=="id") {
			$this->redirect('id/makanan-minuman');
		} else {
			$this->render('index',array("data"=>$data));
		}
	}
	public function actionFoodBeverageMinistryID()
	{
		$data['tpl'] = "id/pelayanan/makanan-minuman";
		$data['en-lang'] = "Food &amp; Beverage";
		$data['en-url'] = "foodbeverage";
		$data['id-lang'] = "Makanan &amp; Minuman";
		$data['id-url'] = "makanan-minuman";
		$this->render('index',array("data"=>$data));
	}
	public function actionLibraryMinistry()
	{
		$data['tpl'] = "en/ministry/library";
		$data['en-lang'] = "Library";
		$data['en-url'] = "library";
		$data['id-lang'] = "Perpustakaan";
		$data['id-url'] = "perpustakaan";
		if (Yii::app()->session['lang']=="id") {
			$this->redirect('id/perpustakaan');
		} else {
			$this->render('index',array("data"=>$data));
		}
	}
	public function actionLibraryMinistryID()
	{
		$data['tpl'] = "id/pelayanan/perpustakaan";
		$data['en-lang'] = "Library";
		$data['en-url'] = "library";
		$data['id-lang'] = "Perpustakaan";
		$data['id-url'] = "perpustakaan";
		$this->render('index',array("data"=>$data));
	}
	public function actionMultimediaMinistry()
	{
		$data['tpl'] = "en/ministry/multimedia";
		$data['en-lang'] = "Multimedia";
		$data['en-url'] = "multimedia";
		$data['id-lang'] = "Multimedia";
		$data['id-url'] = "multimedia";
		if (Yii::app()->session['lang']=="id") {
			$this->redirect('id/multimedia');
		} else {
			$this->render('index',array("data"=>$data));
		}
	}
	public function actionMultimediaMinistryID()
	{
		$data['tpl'] = "id/pelayanan/multimedia";
		$data['en-lang'] = "Multimedia";
		$data['en-url'] = "multimedia";
		$data['id-lang'] = "Multimedia";
		$data['id-url'] = "multimedia";
		$this->render('index',array("data"=>$data));
	}
	public function actionPraiseWorshipMinistry()
	{
		$data['tpl'] = "en/ministry/praiseworship";
		$data['en-lang'] = "Praise &amp; Worship";
		$data['en-url'] = "praiseworship";
		$data['id-lang'] = "Musik";
		$data['id-url'] = "musik";
		if (Yii::app()->session['lang']=="id") {
			$this->redirect('id/musik');
		} else {
			$this->render('index',array("data"=>$data));
		}
	}
	public function actionPraiseWorshipMinistryID()
	{
		$data['tpl'] = "id/pelayanan/musik";
		$data['en-lang'] = "Praise &amp; Worship";
		$data['en-url'] = "praiseworship";
		$data['id-lang'] = "Musik";
		$data['id-url'] = "musik";
		$this->render('index',array("data"=>$data));
	}
	public function actionPrayerMinistry()
	{
		$data['tpl'] = "en/ministry/prayer";
		$data['en-lang'] = "Prayer";
		$data['en-url'] = "prayer";
		$data['id-lang'] = "Doa";
		$data['id-url'] = "doa";
		if (Yii::app()->session['lang']=="id") {
			$this->redirect('id/doa');
		} else {
			$this->render('index',array("data"=>$data));
		}
	}
	public function actionPrayerMinistryID()
	{
		$data['tpl'] = "id/pelayanan/doa";
		$data['en-lang'] = "Prayer";
		$data['en-url'] = "prayer";
		$data['id-lang'] = "Doa";
		$data['id-url'] = "doa";
		$this->render('index',array("data"=>$data));
	}
	public function actionSoundSystemMinistry()
	{
		$data['tpl'] = "en/ministry/soundsystem";
		$data['en-lang'] = "Sound System";
		$data['en-url'] = "soundsystem";
		$data['id-lang'] = "Sound Sistem";
		$data['id-url'] = "soundsistem";
		if (Yii::app()->session['lang']=="id") {
			$this->redirect('id/soundsistem');
		} else {
			$this->render('index',array("data"=>$data));
		}
	}
	public function actionSoundSystemMinistryID()
	{
		$data['tpl'] = "id/pelayanan/soundsistem";
		$data['en-lang'] = "Sound System";
		$data['en-url'] = "soundsystem";
		$data['id-lang'] = "Sound Sistem";
		$data['id-url'] = "soundsistem";
		$this->render('index',array("data"=>$data));
	}
	public function actionStageDesignMinistry()
	{
		$data['tpl'] = "en/ministry/stagedesign";
		$data['en-lang'] = "Stage Design";
		$data['en-url'] = "stagedesign";
		$data['id-lang'] = "Dekorasi";
		$data['id-url'] = "dekorasi";
		if (Yii::app()->session['lang']=="id") {
			$this->redirect('id/dekorasi');
		} else {			
			$this->render('index',array("data"=>$data));
		}
	}
	public function actionStageDesignMinistryID()
	{
		$data['tpl'] = "id/pelayanan/dekorasi";
		$data['en-lang'] = "Stage Design";
		$data['en-url'] = "stagedesign";
		$data['id-lang'] = "Dekorasi";
		$data['id-url'] = "dekorasi";
		$this->render('index',array("data"=>$data));
	}
	public function actionUsherMinistry()
	{
		$data['tpl'] = "en/ministry/ushersgreeters";
		$data['en-lang'] = "Ushers &amp; Greeters";
		$data['en-url'] = "ushersgreeters";
		$data['id-lang'] = "Usher &amp; Penyambut Tamu";
		$data['id-url'] = "usherpenyambuttamu";
		if (Yii::app()->session['lang']=="id") {
			$this->redirect('id/usherpenyambuttamu');
		} else {
			$this->render('index',array("data"=>$data));
		}
	}
	public function actionUsherMinistryID()
	{
		$data['tpl'] = "id/pelayanan/usherpenyambuttamu";
		$data['en-lang'] = "Ushers &amp; Greeters";
		$data['en-url'] = "ushersgreeters";
		$data['id-lang'] = "Usher &amp; Penyambut Tamu";
		$data['id-url'] = "usherpenyambuttamu";
		$this->render('index',array("data"=>$data));
	}
	public function actionWebsiteMinistry()
	{
		$data['tpl'] = "en/ministry/website";
		$data['en-lang'] = "Website";
		$data['en-url'] = "website";
		$data['id-lang'] = "Website";
		$data['id-url'] = "website";
		if (Yii::app()->session['lang']=="id") {
			$this->redirect('id/website');
		} else {
			$this->render('index',array("data"=>$data));
		}
	}
	public function actionWebsiteMinistryID()
	{
		$data['tpl'] = "id/pelayanan/website";
		$data['en-lang'] = "Website";
		$data['en-url'] = "website";
		$data['id-lang'] = "Website";
		$data['id-url'] = "website";
		$this->render('index',array("data"=>$data));
	}

	public function actionSermon()
	{
		$data['tpl'] = "/site/sermon";
		$this->render('index',array("data"=>$data));
	}
	public function actionSermon1()
	{
		$this->render('sermon1');
		$this->render('index',array("data"=>$data));
	}

	public function actionOffering()
	{
		$data['tpl'] = "en/offering";
		if (Yii::app()->session['lang']=="id") {
			$this->redirect('id/persembahan');
		} else {
			$this->render('index',array("data"=>$data));
		}
	}
	public function actionOfferingID()
	{
		$data['tpl'] = "id/persembahan";
		$this->render('index',array("data"=>$data));
	}
	/**
	 * This is the action to handle external exceptions.
	 */
	public function actionError()
	{
	    if($error=Yii::app()->errorHandler->error)
	    {
	    	if(Yii::app()->request->isAjaxRequest)
	    		echo $error['message'];
	    	else
	        	$this->render('error', $error);
	    }
	}

	/**
	 * Displays the contact page
	 */
	public function actionContact()
	{
		$model=new ContactForm;
		if(isset($_POST['ContactForm']))
		{
			$model->attributes=$_POST['ContactForm'];
			if($model->validate())
			{
				$headers="From: {$model->email}\r\nReply-To: {$model->email}";
				mail(Yii::app()->params['adminEmail'],$model->subject,$model->body,$headers);
				Yii::app()->user->setFlash('contact','Thank you for contacting us. We will respond to you as soon as possible.');
				$this->refresh();
			}
		}
		$this->render('contact',array('model'=>$model));
	}

	/**
	 * Displays the login page
	 */
	public function actionLogin()
	{
		$model=new LoginForm;

		// if it is ajax validation request
		if(isset($_POST['ajax']) && $_POST['ajax']==='login-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}

		// collect user input data
		if(isset($_POST['LoginForm']))
		{
			$model->attributes=$_POST['LoginForm'];
			// validate user input and redirect to the previous page if valid
			if($model->validate() && $model->login())
				$this->redirect(Yii::app()->user->returnUrl);
		}
		// display the login form
		$this->render('login',array('model'=>$model));
	}

	/**
	 * Logs out the current user and redirect to homepage.
	 */
	public function actionLogout()
	{
		Yii::app()->user->logout();
		$this->redirect(Yii::app()->homeUrl);
	}
}