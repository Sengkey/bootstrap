<?php $this->pageTitle=Yii::app()->name; ?>

		<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->getBaseUrl(true); ?>/css/sermon.css" />
		<div id="content">
			<div class="synopsis">
				<a class="videotitle" href="http://www.christlivingchurch.com/sermon/allah-menciptakan-manusia-untuk-dapat-menghadapi-masalah/" rel="bookmark" title="Permanent Link to Allah Menciptakan Manusia Untuk Dapat Menghadapi Masalah">Allah Menciptakan Manusia Untuk Dapat Menghadapi Masalah</a>
				<div id="videowrapper">
					<div id="video"></div>
				</div>
				<div style="float:right"><strong>Views: </strong>70<br /><strong>Views: </strong>71</div>
				<strong>Preacher</strong>: Pdt. Abram Suala<br><strong>Date</strong>: 16 September 2012<br><strong>Synopsis</strong>: <br>
			</div>
			<div class="latest">
				<h3>Latest Sermons</h3>

				<div class="relatedvid">
					<br>
					<a href="#">Allah Menciptakan Manusia Untuk Dapat Menghadapi Masalah</a>
					<br><br>
					<a href="#">
						<div class="myimg" style="background:url(video_audio/120916/120916.png);">
							<div class="duration">00:49:54</div>
						</div>
					</a>
					Date: 16 Sep 2012
					<br>Preacher: Pdt. Abram Suala
					<br>Views: 70
				</div>
				<div class="latestvideoseparator"><hr></div>
				<div class="relatedvid no2">
					<br>
					<a href="#">Allah Menciptakan Manusia Untuk Dapat Menghadapi Masalah</a>
					<br><br>
					<a href="#">
						<div class="myimg" style="background:url(video_audio/120916/120916.png);">
							<div class="duration">00:49:54</div>
						</div>
					</a>
					Date: 16 Sep 2012
					<br>Preacher: Pdt. Abram Suala
					<br>Views: 70
				</div>
				<div class="latestvideoseparator"><hr></div>
				<div class="relatedvid no3">
					<br>
					<a href="#">Allah Menciptakan Manusia Untuk Dapat Menghadapi Masalah</a>
					<br><br>
					<a href="#">
						<div class="myimg" style="background:url(video_audio/120916/120916.png);">
							<div class="duration">00:49:54</div>
						</div>
					</a>
					Date: 16 Sep 2012
					<br>Preacher: Pdt. Abram Suala
					<br>Views: 70
				</div>
				<div class="latestvideoseparator"><hr></div>
				<div class="relatedvid no4">
					<br>
					<a href="#">Allah Menciptakan Manusia Untuk Dapat Menghadapi Masalah</a>
					<br><br>
					<a href="#">
						<div class="myimg" style="background:url(video_audio/120916/120916.png);">
							<div class="duration">00:49:54</div>
						</div>
					</a>
					Date: 16 Sep 2012
					<br>Preacher: Pdt. Abram Suala
					<br>Views: 70
				</div>
				<div class="latestvideoseparator"><hr></div>
				<div class="relatedvid no5">
					<br>
					<a href="#">Allah Menciptakan Manusia Untuk Dapat Menghadapi Masalah</a>
					<br><br>
					<a href="#">
						<div class="myimg" style="background:url(video_audio/120916/120916.png);">
							<div class="duration">00:49:54</div>
						</div>
					</a>
					Date: 16 Sep 2012
					<br>Preacher: Pdt. Abram Suala
					<br>Views: 70
				</div>
				<div class="latestvideoseparator"><hr></div>
				<div class="relatedvid no6">
					<br>
					<a href="#">Allah Menciptakan Manusia Untuk Dapat Menghadapi Masalah</a>
					<br><br>
					<a href="#">
						<div class="myimg" style="background:url(video_audio/120916/120916.png);">
							<div class="duration">00:49:54</div>
						</div>
					</a>
					Date: 16 Sep 2012
					<br>Preacher: Pdt. Abram Suala
					<br>Views: 70
				</div>
				<div class="latestvideoseparator"><hr></div>
				<div class="relatedvid no7">
					<br>
					<a href="#">Allah Menciptakan Manusia Untuk Dapat Menghadapi Masalah</a>
					<br><br>
					<a href="#">
						<div class="myimg" style="background:url(video_audio/120916/120916.png);">
							<div class="duration">00:49:54</div>
						</div>
					</a>
					Date: 16 Sep 2012
					<br>Preacher: Pdt. Abram Suala
					<br>Views: 70
				</div>
				<div class="latestvideoseparator"><hr></div>
				<div class="relatedvid no8">
					<br>
					<a href="#">Allah Menciptakan Manusia Untuk Dapat Menghadapi Masalah</a>
					<br><br>
					<a href="#">
						<div class="myimg" style="background:url(video_audio/120916/120916.png);">
							<div class="duration">00:49:54</div>
						</div>
					</a>
					Date: 16 Sep 2012
					<br>Preacher: Pdt. Abram Suala
					<br>Views: 70
				</div>
				<div class="latestvideoseparator"><hr></div>
				<div class="relatedvid no9">
					<br>
					<a href="#">Allah Menciptakan Manusia Untuk Dapat Menghadapi Masalah</a>
					<br><br>
					<a href="#">
						<div class="myimg" style="background:url(video_audio/120916/120916.png);">
							<div class="duration">00:49:54</div>
						</div>
					</a>
					Date: 16 Sep 2012
					<br>Preacher: Pdt. Abram Suala
					<br>Views: 70
				</div>
				<div class="latestvideoseparator"><hr></div>
				<div class="relatedvid no10">
					<br>
					<a href="#">Allah Menciptakan Manusia Untuk Dapat Menghadapi Masalah</a>
					<br><br>
					<a href="#">
						<div class="myimg" style="background:url(video_audio/120916/120916.png);">
							<div class="duration">00:49:54</div>
						</div>
					</a>
					Date: 16 Sep 2012
					<br>Preacher: Pdt. Abram Suala
					<br>Views: 70
				</div>
				<div class="latestvideoseparator"><hr></div>
			</div>
			<div class="clear"></div>
			<div class="rowseparator"></div>
		</div>
