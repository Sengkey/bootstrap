<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","pengakuaniman");
?>
		<div id="content">
			<h1><a href="pengakuaniman" title="Pengakuan Iman">Pengakuan Iman</a></h1> 
			<ul>
				<li>
					Kami percaya kepada satu Allah, Bapa yang Mahakuasa, pencipta manusia, langit dan bumi serta seluruh alam semesta.
				</li>
				<li>
					Kami percaya kepada Yesus Kristus, Anak-Nya yang Tunggal, Tuhan kita. Yang dikandung dari 
					<a href="http://id.wikipedia.org/wiki/Roh_Kudus" target="_blank">Roh Kudus</a>, lahir dari anak dara 
					<a href="http://id.wikipedia.org/wiki/Maria" target="_blank">Maria</a>. Yang menderita sengsara di bawah pemerintahan 
					<a href="http://id.wikipedia.org/wiki/Pontius_Pilatus" target="_blank">Pontius Pilatus</a>, disalibkan, mati dan dikuburkan, 
					turun ke dalam kerajaan maut. Pada hari yang ketiga bangkit dari antara orang mati, naik ke 
					<a href="http://id.wikipedia.org/wiki/Surga" target="_blank">surga</a>, duduk di sebelah kanan Allah, Bapa yang Mahakuasa. 
					Dan dari sana Ia akan datang kembali untuk mengadili orang yang hidup dan yang mati.
				</li>
				<li>
					Kami percaya kepada Roh Kudus, Gereja yang kudus dan satu kesatuan Tubuh Kristus, persekutuan orang kudus, pengampunan dosa, 
					<a href="http://id.wikipedia.org/wiki/Tubuh_kemuliaan_Yesus#Tubuh_kebangkitan" target="_blank">kebangkitan badan</a>, dan hidup yang kekal.
				</li>
				<li>
					Kami percaya kepada satu Allah dengan 3 pribadi: Allah Bapa, Allah Putra dan Allah Roh Kudus.
				</li>
				<li>
					Kami percaya bahwa Alkitab adalah Firman Allah yang diilhamkan oleh Roh Kudus, tanpa salah, dan sumber otoritas bagi iman, 
					perbuatan dan pengajaran rohani (doctrine)
				</li>
				<li>
					Kami percaya pada baptisan air secara diselamkan, sebagai lambang kematian bersama kematian Kristus, lambang kebangkitan dan 
					kehidupan kembali bersama Kristus.
				</li>
				<li>
					Kami percaya pada Perjamuan Kudus untuk mengingat pengorbanan, kematian, kebangkitan dan kedatangan Tuhan Yesus Kristus yang ke 2 
					kali.
				</li>
				<li>
					Kami percaya bahwa pengampunan dosa dan keselamatan umat manusia adalah anugerah Allah melalui iman percaya kepada 
					Tuhan Yesus Kristus dan karya keselamatanNya di kayu salib
				</li>
				<li>
					Kami percaya bahwa Yesus Kristus adalah satu-satunya jalan keselamatan rohani dan jasmani, kebenaran yang sejati, dan 
					hidup yang kekal.
				</li>
			</ul>
		</div>
