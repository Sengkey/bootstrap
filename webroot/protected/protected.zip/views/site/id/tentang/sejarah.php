<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","sejarah");
?>
		<div id="content">
			<div id="pastormsg">
				<p class="greeting"><b>Selamat datang saudara terkasih dalam Tuhan,</b></p>
				<p>Kami percaya dengan menjalankan perintahNya maka Tuhan akan membuat 2011 sebagai tahun terbaik kami.</p>
				<p>Mari berdoa &amp; melayani bersama sebagai satu kesatuan Tubuh Kristus dan keluarga yang saling mengasihi melalui karya penebusanNya.</p>
			</div>
			<h1><a href="sejarah" title="Sejarah">Sejarah CLC</a></h1>
			<b>Christ Living Church, gereja yang penuh kasih</b>
			<br />
			Gereja CLC memulai kebaktian pertamanya pada tanggal 18 Juni 2006 jam 10.00 pagi, menggunakan gedung School of Art, Peakhurst NSW. 
			Kebaktian pertama dihadiri oleh sekitar 30 orang (termasuk anak-anak). 
			Setelah kebaktian, sementara menikmati hidangan makan siang bersama, tiba-tiba ada sebuah pesawat yang terbang tinggi tepat di atas kami 
			dan membuat 2 kalimat dengan asap di langit, bertuliskan, "Trust in Jesus alone" dan "Jesus saves".
			<br /><br />
			<a href="http://www.christlivingchurch.com/home/gallery.html?album=message-in-the-sky">
				<img src="http://www.christlivingchurch.com/home/clc_files/images/sejarah_clc_trustinjesusalone.jpg" alt="Trust in Jesus alone" class="floatleft" />
			</a>Saat itu, di hati saya, saya tahu bahwa Tuhan menggunakan dua "tanda" di langit untuk mengirimkan pesan bahwa Dia telah meneguhkan 
			pelayanan CLC dan Dia memberikan pengurapan dan berkatNya kepada jemaat yang Dia kasihi. Beberapa bulan kemudian, 
			saya merasakan bahwa Allah tidak lagi membiarkan kami menggunakan gedung kecil tersebut, sehingga saya mengumumkan kepada jemaat bahwa 
			kami akan menggunakan gedung ini sampai ulang tahun CLC yang pertama.
			<br /><br />
			Kami sangat senang, karena kami merasakan hadiratNya di kebaktian Minggu kami yang penuh kuasa dan dinamis. 
			Banyak keajaiban yang terjadi di antara jemaat. 
			Anggota gereja mulai disatukan sebagai satu keluarga Kristus yang sehati. Mereka saling membantu dan melakukan pelayanan 
			dengan penuh sukacita, walaupun kami harus mengangkut dan membongkar alat-alat musik dan pengaturan suara setiap hari Minggu. 
			Tuhan mengirimkan beraneka anggota gereja dari latar belakang budaya yang baru, tetapi juga menyaring beberapa orang untuk keluar 
			dari gereja. Banyak jiwa diubahkan secara drastis.
			<br /><br />
			<a href="http://www.christlivingchurch.com/home/gallery.html?album=first-sunday-service-in-st-paul-anglican-kogarah">
				<img src="http://www.christlivingchurch.com/home/clc_files/images/sejarah_clc_kogarah.jpg" alt="CLC 1st Sunday Serv9ce in Kogarah" class="floatright" />
			</a>Dalam satu tahun, Allah membuat gereja bertumbuh sampai dengan 50-60 orang. Kami mempunyai pertumbuhan gereja 100%. 
			Gedung tersebut menjadi sangat kecil bagi kami, sehingga kami mulai mencari gedung baru dengan kapasitas yang lebih besar. 
			Allah Maha Kuasa! Dia menggenapi apa yang Dia taruh di hati saya dengan menyediakan gedung baru yang indah bagi gerejaNya. 
			Seminggu setelah merayakan ulang tahun CLC yang pertama dengan kebaktian Minggu pada tanggal 17 Juni 2007, 
			kami pindah ke Aula St. Paul's Anglican Church, Kogarah NSW. Gereja CLC melanjutkan pelayanan di tempat baru ini sejak 24 Juni 2007. 
			Tuhan memberkati kami dengan tempat ini dan membuat kami bertumbuh lebih lagi dengan jemaat dan pelayanan yang berkualitas.
			<br /><br />
			Walaupun awalnya sistem organisasi gereja CLC berbeda, tapi sejak awal CLC sudah diterima dan diperlakukan seperti "anggota keluarga" 
			oleh jemaat gereja St. Paul. CLC didukung begitu rupa oleh gereja by St. Paul, terutama dengan menyediakan banyak fasilitas untuk 
			pelayanan CLC. Bersama dengan gereja St. Paul di kompleks tersebut CLC bekerja sama dengan jemaat St. Paul dalam pelayanan dan 
			aktivitas di dalam proyek pembangungan gereja. Tuhan benar-benar memberkati gereja CLC di tempat ini. 
			Berdasarkan laporan Rapat Umum Tahunan kami pada Desember 2010, rata-rata kehadiran jemaat tiap kebaktian Minggu kami pada tahun lalu 
			adalah 125 - 150 orang. Terpujilah Tuhan, semua kemuliaan hanya untukNya.
			<br /><br />
			<a href="http://www.christlivingchurch.com/home/gallery.html?album=clc-become-st-pauls-anglican-member-ceremony">
				<img src="http://www.christlivingchurch.com/home/clc_files/images/sejarah_clc_stpaulmember.jpg" alt="CLC and St Paul Church Anglican" class="floatleft" />
			</a>Sebenarnya, gereja CLC sudah lama ditawari untuk menjadi anggota gereja St. Akan tetapi, setelah mempertimbangkan tawaran ini 
			selama setahun, akhirnya, CLC memutuskan untuk menerimanya dengan senang hati berdasarkan prinsip otonomi dengan saling menghormati 
			dan menghargai otoritas tiap komunitas. Dengan demikian, sejak 15 Maret 2009, secara resmi, 
			CLC menjadi anggota keluarga gereja St. Paul’s Anglican, dengan jemaat yang setaraf di organisasi. 
			Keanggotaan ini berdasarkan kesatuan Tubuh Kristus dan untuk mencapai tujuan gerejaNya yaitu menjangkau jiwa di seluruh dunia dan 
			memperluas pelayanan untuk komunitas dari berbagai latar budaya di Australia.
			<br /><br />
			Keanggotaan ini tidak mengubah prinsip gereja CLC seperti: doktrin, liturgi, finansial, manajemen, kepemimpinan, dsb. 
			Puji Tuhan para jemaat gereja St. Paul menerima CLC sebagai anggota keluarga yang baru. 
			Di bawah karuniaNya, melalui kesatuan ini, kami dikuatkan untuk melakukan pelayanan dengan lebih efektif dan misi yang lebih produktif 
			ke dunia. Sekarang sudah terbukti! Menggunakan teknologi Internet, team IT CLC membangung website yang sangat efektif untuk 
			diakses orang-orang dari seluruh penjuru dunia.
			<br /><br />
			Dari website ini, mereka dapat mengikuti <a href="http://www.christlivingchurch.com/sermon">video kotbah online</a>, 
			<a href="http://indonesia.christlivingchurch.com/kotbah-mp3-online.html">mengunduh audio mp3 kotbah ke komputer</a>, 
			<a href="http://www.christlivingchurch.com/home/id/doa.html#permohonandoa">mengirimkan permohonan doa</a>, menikmati 
			<a href="http://www.christlivingchurch.com/home/gallery.html">galeri foto</a>, dan sebagainya. 
			Sejak tahun 2009, kebaktian umum kami di hari Minggu sudah disiarkan secara langsung melalui Internet ke seluruh dunia. 
			Dengan demikian, walaupun CLC adalah gereja lokal dengan jemaat yang terbatas, tapi mempunyai dampak global yang tidak terbatas. 
			Beberapa undangan pelayanan global datang dari Afrika Selatan, India, Filipina, Vietnam, Thailand, China, Hongkong, Myanmar, 
			Indonesia, etc. Beberapa gereja di negara tersebut meminta gereja CLC untuk menjadi partner mereka dalam pelayanan dan misi. 
			Satu gereja di Thailand meminta CLC untuk membantu pelayanan mereka sebagai mitra gereja untuk kemuliaan Tuhan.  
			<br /><br />
			SejarahNya di CLC sudah dimulai dan akan tetap berlanjut dengan lebih spektakular di masa depan. Amin!
			<br /><br /><br />
			Dalam berkat Tuhan Yesus,
			<br /><br />
			<b><u>Ir. Agus Rahardja DS, MA Mis.</u></b>
			<br /><br />
			Gembala Sidang Christ Living Church
		</div>
