<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","visimisi");
?>
		<div id="content">
			<h1><a href="visimisi" title="Visi">Visi</a></h1> 
			Gereja Christ Living Church adalah:
			<ul>
				<li>
					gereja yang berpusat pada Yesus Kristus
				</li>
				<li>
					gereja yang berorientasi pada Misi yang didasarkan kepada Alkitab
				</li>
				<li>
					gereja yang berfokus kepada Firman Allah
				</li>
				<li>
					gereja lokal yang memberikan dampak global
				</li>
				<li>
					gereja yang menjadi bagian kesatuan Tubuh Kristus
				</li>
			</ul>
			<br />
			<h1><a href="visimisi" title="Misi">Misi</a></h1> 
			Gereja Christ Living Church membangun dan menggerakkan jemaatnya:
			<ul>
				<li>
					untuk tumbuh dan mendapatkan berkat dalam tubuh, roh, dan jiwa
				</li>
				<li>
					untuk taat akan Amanat Agung (Matius 28:19-20)
				</li>
				<li>
					untuk pergi melakukan misi dan memberikan dampak kepada dunia melalui teknologi dan mengirim misionaris
				</li>
				<li>
					untuk melakukan pelayanan sesuai dengan talenta, anugrah dan panggilan dari Allah
				</li>
				<li>
					untuk bekerja sama dengan jalinan pelayanan yang lain
				</li>
			</ul>
		</div>
