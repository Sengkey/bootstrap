<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","dasarpemikiran");
?>
		<div id="content">
			<h1><a href="dasarpemikiran" title="Dasar Pemikiran">Dasar Pemikiran</a></h1> 
			Secara umum, Gereja
			Tuhan (orang-orang yang percaya Kristus), mengemban dua tanggung jawab
			utama, yaitu PERINTAH AGUNG (Markus 12:30,31) dan AMANAT AGUNG (Matius
			28:19,20) Kristus.
			<br /><br />
			<strong>Perintah Agung</strong> di Markus 12:30,31 tertulis sbb: "<em>Kasihilah
			Tuhan, Allahmu, dengan segenap hatimu dan dengan segenap jiwamu dan
			dengan segenap akal budimu dan dengan segenap kekuatanmu. Dan hukum yang kedua ialah: Kasihilah sesamamu manusia seperti dirimu sendiri. Tidak ada hukum lain yang lebih utama dari pada kedua hukum ini</em>." 
			<br /><br />
			<strong>Perintah Agung</strong> ini mengingatkan Gereja tentang <strong>eksistensinya</strong>, yaitu melayani Tuhan dan  sesama manusia berdasarkan <em>Kasih</em>.
			Kasih adalah motivasi tertinggi Gereja dalam mengerjakan pelayanannya,
			menjaga keutuhan dan kesatuan Tubuh Kristus serta menyelesaikan
			masalah-masalah yang timbul dalam kehidupan bergereja. Kasih pasti
			menemukan solusi yang positif dalam setiap masalah dan menjamin
			penyelesaiannya secara tuntas dan damai. Bila Kasih dalam Gereja pudar,
			maka Gereja sesungguhnya telah kehilangan jati diriNya dan tidak lebih
			dari  organisasi sosial biasa. 
			<br /><br />
			Pelanggaran prinsip Kasih
			dalam bentuk apapun akan membuat Gereja "mati selagi hidup". Sang
			jenius Einstein mengakui bahwa "mati selagi hidup" adalah hal yang
			paling mengerikan, sehingga kita harus mencegahnya dengan cara tinggal
			dalam Kasih Allah dan memelihara KasihNya agar tetap hangat dan membara
			baik dalam ibadah kepada Tuhan maupun dalam membina hubungan dengan
			sesama manusia. <strong>Perintah  Agung</strong> ini adalah barometer
			hubungan pribadi dengan Tuhan dan sesama. Tuhan mengingatkan jemaat di
			Korintus dan Efesus, bahwa tanpa Kasih semua prestasi Gereja akan
			sia-sia (1 Korintus 13:1-3; Wahyu 2:1-7). 
			<br /><br />
			Kasih memurnikan
			Gereja dari praktek-praktek politik dalam Gereja, fitnah, materialisme,
			gossip, iri hati, kebencian, dan lain-lain. Kasih memungkinkan Gereja
			bertumbuh dalam atmosfir sukacita dan damai sejahtera yang sehat,
			dinamis, dan supra natural, sehingga pertumbuhannya tak terbatas,
			hadirat Tuhan nyata, ibadah dan pelayanannya penuh mujizat.
			<br /><br />
			<strong>Amanat Agung</strong> tercatat di Mat.28:19,20 sbb: "<em>Karena
			itu pergilah, jadikanlah semua bangsa murid-Ku dan baptislah mereka
			dalam nama Bapa dan Anak dan Roh Kudus, dan ajarlah mereka melakukan
			segala sesuatu yang telah Kuperintahkan kepadamu. Dan ketahuilah, Aku
			menyertai kamu senantiasa sampai kepada akhir zaman.</em>"
			<br /><br />
			<strong>Amanat Agung</strong> menetapkan <strong>sasaran akhir</strong> untuk setiap kegiatan Gereja, yaitu <em>jiwa-jiwa terhilang diselamatkan</em>. Makin tinggi sasaran <em>jiwa</em> yang ditetapkan, makin tinggi pula  "harga" yang harus dibayar untuk mencapainya. Tanpa penetapan sasaran jiwa<em>, </em>Gereja akan terjebak pada rutinitas  kegiatan sehari-hari, sehingga tanpa sadar <em>kegiatan</em> menjadi sasaran pelayanannya. 
			<br /><br />
			Gereja
			yang demikian akan tetap berjalan dengan kegiatan rutinnya, tetap
			dengan slogan "selamatkan jiwa", tapi tidak misioner. Tetap eksis, tapi
			tidak berfungsi sebagai kepanjangan tangan Tuhan untuk menyelamatkan
			jiwa-jiwa terhilang. Gereja yang tidak misioner, akan mudah terseret
			pada jerat materialisme dan kecenderungan membangun kerajaannya sendiri
			(yang seharusnya membangun Kerajaan Allah). Gereja yang demikian telah
			menyia-nyiakan Karya Keselamatan Kristus bagi dunia ini. Sebab itu
			keberhasilan pelayanan Gereja tidak diukur dari berapa banyak keuangan,
			asset atau fasilitas yang dimilikinya, tetapi dari <em>pertumbuhan kualitas rohani</em> dan <em>kuantitas jemaat</em>
			yang berasal dari jiwa-jiwa terhilang yang berhasil dijangkaunya.
			Contoh gereja yang sukses saat ini ada di China, meskipun mereka tidak
			memiliki gedung gereja dan berbakti di hutan-hutan, gua-gua, dsb
			sebagai "underground church", tapi tiap hari ada 60,000 orang percaya
			dan terima Yesus sebagai Juru Selamat.
			<br /><br />
			Di samping menetapkan sasaran jiwa, Tuhan juga mengajarkan <strong>pola kerja</strong>
			untuk mencapai sasaran tersebut, yaitu dengan "menjala" manusia. Dalam
			Injil Matius 4:19 Yesus berkata kepada murid-muridNya: "<em>Mari, ikutlah Aku, dan kamu akan Kujadikan penjala manusia</em>." <strong>Jala</strong> sering  diinterpretasikan sebagai <em>net-work </em>(jaringan
			kerja)di antara sesama Tubuh Kristus yang terikat dan rapi
			tersusundalam semua bagian pelayanannya (Efesus 4:16). Tuhan tidak
			mengenal adanya "super star" atau "one man show" dalam Gereja karena
			semua bagian anggota Tubuh Kristus harus terlibat dalam pelayanan
			sesuai fungsinya masing-masing. Karena itu keberhasilan Gereja adalah
			keberhasilan bersama dari seluruh JemaatNya karena dipimpin oleh
			Kristus Sang Kepala Gereja.
			<br /><br />
			<strong>Team work</strong> dalam pelayanan gereja sangatlah dianjurkan dengan tujuan untuk menjalin network, namun terlebih lagi ini tujuan utama suatu team work adalah "<em>sama-sama kerja</em> supaya <em>sama-sama ringan". </em>Dalam
			kerja team work, tidak boleh ada yang merasa "superior" sebab tidak ada
			anggota team yang dapat berfungsi tanpa ditopang oleh fungsi anggota
			team lainnya. Team-work yang efektif selalu berorientasi pada <em>hasil kerja</em>
			(end results ). Anggota team dapat bekerja dengan fleksibel sesuai
			dengan waktu, talenta, dan gaya  masing-masing namun tetap pada arah
			sasaran yang telah ditetapkan. Team work yang demikian akan dinamis dan
			produktif, pelayanan berjalan baik dan jiwa-jiwa dimenangkan !
			Meskipun orientasinya pada hasil kerja, team-work yang efektif tidak
			mengabaikan <em>proses</em> (cara kerja) dalam mencapai hasil
			tersebut. Efektivitas dijaga dengan terus mengevaluasi proses yang
			telah dilakukan sehingga dapat dilakukan perbaikan-perbaikan untuk
			meningkatkan hasilnya. Untuk mengevaluasi efektivitas ini, kita semua
			harus sepakat untuk tidak menunjuk "siapa yang salah", karena hal ini
			hanya akan melukai orang lain. Sebaiknya kita harus bertanya "apa yang
			salah", maka kita akan berusaha menemukan masalahnya dan sekaligus
			memperbaikinya, dan meningkatkan apa yang sudah dianggap "baik".
			<br /><br />
			Ketika
			masing-masing anggota team bekerja dan melakukan fungsinya, bisa saja
			terjadi "pergesekan". Pergesekan dalam kerja itu "sehat", karena
			menunjukkan adanya semangat untuk bertanggung jawab serta keinginan
			untuk maju. Ibarat mobil yang berjalan maju dengan pesat, maka
			pergesekan antara ban mobil dengan jalan dan udara yang dilaluinya juga
			akan makin besar. Pergesekan menjadi "tidak sehat" bila motivasinya
			ingin menjatuhkan orang lain demi kepentingan pribadi dan insecurity
			(cemburu melihat keberhasilan orang lain karena dianggap sebagai
			ancaman terhadap kenyamanan kedudukannya). Karena itu, saling
			menghargai fungsi dan kerja orang lain akan membuat sukses kerja sama
			kita bersifat jangka panjang.
			<br /><br />
			Kerja sama atau net-working di antara sesama Tubuh Kristus adalah pola Alkitabiah yang sudah terbukti <em>efektif</em>
			untuk melakukan Amanat Agung. Lewat net-working ini Gereja dihindarkan
			dari kesombongan rohani dan disadarkan bahwa Tubuh Kristus itu saling
			membutuhkan dan saling melengkapi. Net-working juga dapat menjadi alat
			Tuhan untuk membangun <em>karakter</em> rendah hati dan <em>kesatuan</em> Gereja, karena kita dapat  belajar dari keunggulan maupun kekurangan orang lain. 
			<br /><br />
			<strong>Kesatuan</strong>
			adalah kata kunci dalam net-working. Kesatuan ibarat bahan bakar yang
			menggerakkan masing-masing potensi Tubuh Kristus sehingga dapat saling
			melengkapi. Segala bentuk pertikaian dan perpecahan dalam Gereja adalah
			bukti keberhasilan roh pemecah untuk mengalihkan perhatian Gereja dari
			pencapaian Amanat Agung yang mulia kepada pemuasan kedagingan yang rendah. 
			<br /><br />
			Kalau Gereja ingin melakukan Amanat Agung, tidak
			ada pola kerja yang lebih terpercaya dan efektif selain net-working,
			baik di antara jemaat dalam satu organisasi Gereja maupun dengan
			organisasi yang lain, karena pada hakekatnya semua Gereja adalah rekan sekerja Tuhan dalam memenangkan jiwa-jiwa terhilang. 
			<br /><br />
		</div>
