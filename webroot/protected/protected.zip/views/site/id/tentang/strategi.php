<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","strategi");
?>
		<div id="content">
			<h1><a href="strategi" title="Strategi">Strategi</a></h1>
			<b>CLC adalah</b> gereja yang percaya kepada Tuhan Yesus Kristus dan mematuhi <b>Amanat Agung</b>
			<br /><br />
			<b>Mat.28:19,20
			<br />
			"<em>Karena itu pergilah, jadikanlah semua bangsa muridKu dan baptislah mereka dalam nama Bapa dan Anak dan Roh Kudus, dan ajarlah mereka melakukan segala sesuatu yang telah Kuperintahkan kepadamu. Dan ketahuilah, Aku menyertai kamu senantiasa sampai kepada akhir zaman. Amin</em>".
			</b>
			<br /><br />
			Jadi, strategi ini dibuat untuk membangun kehidupan rohani jemaat denga efektif dan menggerakkan mereka untuk memenuhi Amanat Agung
			<br /><br />
			<ul>
				<li>
					<b>Menggerakkan jemaat</b> daripada menggunakan pelayan penuh waktu
				</li>
				<li>
					<b>Membangun</b> jemaat <b>untuk bertumbuh</b> dalam roh
				</li>
				<li>
					Membuat sebuah <b>"sistem pelayanan"</b> yang <b>memenuhi kebutuhan mereka secara efektif</b> dalam setiap tingkatan dan umur
				</li>
				<li>
					Melibatkan mereka di dalam pelayanan dan melatih mereka <b>untuk menjadi terampil di dalam pelayanan</b>
				</li>
				<li>
					Mengirim mereka ke <b>ladang-ladang misi</b>
				</li>
			</ul>
			<br />
			<h2>Pelayanan</h2>
			CLC menggunakan sistem pelayanan yang "sederhana". Sistem ini dibuat untuk <b>membangun kehidupan rohani jemaat dengan efektif</b>:
			<ul>
				<li>
					Dengan <b>pelayanan khusus</b> terhadap setiap tingkatan dan usia
				</li>
				<li>
					Untuk mencapai <b>target rohani yang terukur</b>, yang dibutuhkan untuk setiap tingkatan untuk bertumbuh ke tingkat selanjutnya sebagai jemaat yang lebih dewasa dan bertanggung jawab. 
				</li>
				<li>
					Untuk melibatkan mereka <b>di dalam pelayanan gereja</b> sesuai dengan panggilan, talenta dan berkat Allah atas mereka
				</li>
				<li>
					Untuk menggerakkan mereka <b>secara sinergi</b> untuk memenuhi <a href="id/visimisi">visi misi</a> gereja
				</li>
			</ul>
			<br />
			<h2>Bagaimana menjalankan sistem tersebut?</h2>
			<ul>
				<li>
					Jemaat diminta untuk mengisi daftar pertanyaan untuk mengenali tingkatan mereka yang diklasifikasikan ke dalam <b>3 tingkatan</b>
				</li>
				<li>
					Tujuan dari klasifikasi ini adalah <b>untuk memberikan pelayanan yang efektif dan khusus</b> kepada setiap tingkatan sesuai dengan kebutuhan rohani mereka
				</li>
				<li>
					Kemudian beberapa <b>target rohani yang terukur</b> dari setiap tingkatan harus dicapai agar bertumbuh ke tingkatan selanjutnya
				</li>
				<li>
					Setiap tingkatan jemaat akan dilibatkan ke dalam pelayanan-pelayanan dan pekerjaan misi <b>sesuai dengan</b> pertumbuhan rohani mereka
				</li>
			</ul>
			<br />
			<h2><a href="strategi" title="Strategi">Klasifikasi</a></h2>
			CLC adalah Gereja yang penuh Kasih dan Belas Kasihan yang
			<ul>
				<li>Mencapai mereka yang tidak dapat dicapai</li>
				<li>Menyentuh mereka yang tidak dapat disentuh</li>
				<li>Mengasihi mereka yang tidak dapat dikasihi</li>
			</ul>
			<br /><br />
			<h2><strong>Tingkat 1 dari <font color="#FF0000">C</font>LC<br /><font color="#FF0000">C</font> = <font color="#FF0000">C</font>hrist is personal saviour</strong> (Kristus adalah Juru Selamat Pribadi)</h2>
			<ul>
				<li>
					Apapun latar belakang rohani jemaat, mereka akan dilayani sampai mereka menerima Tuhan Yesus Kristus sebagai Juru Selamat pribadi mereka.
				</li>
				<li>
					<b>Target tingkat ini:</b>
					<ul>
						<li>
							<b>Keselamatan</b> jemaat oleh kasih karunia Allah
						</li>
						<li>
							<b>Perubahan</b> jemaat menjadi "pengikut Kristus yang lahir baru"
						</li>
						<li>
							<b>Mengerti</b> prinsip dasar keKristenan <b>untuk menjadi jemaat yang bertanggung jawab</b>
						</li>
					</ul>
				</li>
			</ul>
			<br /><br />
			<h2><strong>Tingkat 2 dari C<font color="#FF0000">L</font>C<br /><font color="#FF0000">L</font> = <font color="#FF0000">L</font>ove God, <font color="#FF0000">L</font>ove The Church</strong> (Mengasihi Allah, mengasihi gereja)</h2>
			<ul>
				<li>
					Jemaat harus menjadi murid-murid yang dapat mempraktekkan kasih Allah dengan mengasihi gerejaNya
				</li>
				<li>
					<b>Target level ini:</b>
					<ul>
						<li>
							<b>Keterlibatan</b> jemaat di dalam setidaknya SATU pelayanan gereja (atau lebih) sesuai dengan talenta, berkat dan panggilan Allah
						</li>
					</ul>
				</li>
			</ul>
			<br /><br />
			<h2><strong>Tingkat 3 dari CL<font color="#FF0000">C</font><br /><font color="#FF0000">C</font> = <font color="#FF0000">C</font>ompassion to the world</strong> (Belas kasihan kepada dunia)</h2>
			<ul>
				<li>
					Kedewasaan dari kasih jemaat kepada Allah harus dikembangkan tidak hanya untuk gereja tetapi juga untuk dunia.
				</li>
				<li>
					Mereka harus memenuhi panggilan Allah yang tertinggi di dalam kehidupan mereka dengan They have to fulfil God’s highest calling in their lives by menjangkau dunia bagi Yesus (melakukan misi Allah)
				</li>
				<li>
					<b>Target level ini:</b>
					<ul>
						<li>
							<b>Melengkapi dan melatih</b> jemaat dalam teologi, kepemimpinan dan pelatihan keterampilan pelayanan
						</li>
						<li>
							<b>Mengirimkan</b> SATU jemaat untuk membawa SATU orang ke gereja dalam SATU tahun (Proyek misi 1-1-1)
						</li>
						<li>
							<b>Membantu dan menyiapkan</b> jemaat untuk memenuhi panggilan Tuhan tertinggi dalam kehidupan mereka sebagai penginjil, misionaris, pendeta, pemimpin, dll
						</li>
					</ul>
				</li>
			</ul>
		</div>
