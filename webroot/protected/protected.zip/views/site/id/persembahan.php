<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","persembahan");
?>
		<div id="content">
			<h1><a href="persembahan" title="Persembahan">Persembahan</a></h1>
			Jemaat CLC memberikan persembahan yang terbaik kepada Tuhan. 
			Persembahan ini merupakan cermin kasih kami kepada Tuhan yang lebih dulu mengasihi kami. 
			Ini juga kesempatan terbaik untuk mendukung pekerjaan Tuhan di CLC, yaitu melakukan misi pekabaran Injil ke seluruh dunia, 
			melalui para misionaris maupun teknologi internet.
			<br /><br />
			Jemaat CLC memberkati karena sudah lebih dulu diberkati, sehingga persembahan kami dilakukan dengan sukacita dan rasa syukur kepada 
			Tuhan karena sadar bahwa segala sukses dan berkat itu semata-mata karena anugerah dan kasih karunia Tuhan. 
			Itu tercermin dari doa persembahan seperti di bawah ini: 
			<br /><br />
			<center>
				<br /><b>DOA PERSEMBAHAN</b>
				<br />
				<br />Terpujilah Engkau ya Tuhan, Allah Bapa kami,
				<br />Dari selama-lamanya sampai selama-lamanya.
				<br />
				<br />Ya Tuhan, punyaMu-lah kebesaran, kejayaan,
				<br />kehormatan, keagungan dan kekayaan.
				<br />Ya, segala-galanya, yang ada di langit dan di bumi,
				<br />sebab kekayaan dan kemuliaan berasal dari Mu.
				<br />Dan Engkaulah yang berkuasa atas segala-galanya.
				<br />
				<br />Dalam tanganMu-lah kuasa untuk membesarkan dan
				<br />mengokohkan segala-galanya.
				<br />Kami mengasihi Engkau, karena Engkau
				<br />lebih dulu mengasihi kami.
				<br />
				<br />Engkaulah Allah yang menguji hati dan
				<br />berkenan kepada keikhlasan,
				<br /><br />maka kami mempersembahkan yang terbaik,
				<br />dengan hati tulus dan bersuka cita
				<br />
				<br />Dalam nama Tuhan Yesus kami berdoa.
				<br />Haleluya, Amin !!!
			</center>
			<br /><br />
			Persembahan di CLC dilakukan sbb:
			<ul>
				<li>
					<b>Persembahan Persepuluhan</b>. Jumlahnya minimal 10% dari "take home pay" income/penghasilan jemaat.
				</li>
				<li>
					<b>Persembahan khusus</b>. Jumlahnya tidak ditetapkan nominalnya, 
					tapi tetap merupakan persembahan terbaik yang lahir dari hati yang mengasihi Tuhan.
				</li>
			</ul>
			<br />
			Persembahan itu dapat dimasukkan langsung ke kantong persembahan pada waktu Sunday Service setiap hari Minggu atau ditransfer langsung ke:
			<br />
			<br /><b>Bank:</b> Westpac Bank
			<br /><b>Account Name:</b> Christ Living Church Incorporated
			<br /><b>BSB:</b> 032275
			<br /><b>Acc. No:</b> 187114
			<br /><br />
			Semua persembahan jemaat dikelola oleh Team Keuangan CLC dipimpin oleh seorang bendahara. 
			CLC mengelola uang persembahan jemaat dengan sistim manajemen terbuka, 
			artinya setiap jemaat berhak melihat / memeriksa kebenaran pembukuan keuangan CLC. 
			Untuk mempertanggung jawabkan dan menjamin kebenaran laporan keuangan CLC, di setiap akhir tahun fiskal, 
			pembukuan CLC diaudit oleh Akuntan Publik dan dilaporkan ke pemerintah Australia sebagai bagian dari laporan tahunan kegiatan pelayanan CLC.
			<br /><br />
			Keuangan CLC digunakan sepenuhnya untuk membiayai operasional dan fasilitas pelayanan yang dibutuhkan. 
			Di samping itu CLC juga ikut mendukung pelayanan misi di seluruh dunia dalam berbagai bidang, antara lain: 
			membiayai seminar-seminar rohani di Indnonesia, membiayai para misionaris di desa-desa di Indonesia, 
			mendukung Sekolah Alkitab di Indonesia, memberikan bea siswa untuk anak-anak yang kurang beruntung, dll.
			<br /><br />
			Kalau Anda tergerak untuk mendukung pelayanan CLC dalam bentuk apa saja, Anda dapat menghubungi Bendahara CLC, yaitu : 
			Willy Ramlie (+61 433 186 702) atau dapat langsung mengirimkan dukungan Anda ke nomor Bank Account CLC di atas.
			<br /><br />
			Atas nama seluruh jemaat CLC, kami mengucapkan banyak terima kasih atas doa dan  persembahan terbaik Anda untuk pelayanan CLC 
			demi kemuliaan nama Tuhan Yesus Kristus dan perluasan KerajaanNya di seluruh dunia.
			<br /><br />
			<blockquote class="verse"> 
				"Karena itu, saudara-saudaraku yang kekasih, berdirilah teguh, jangan goyah, dan giatlah selalu dalam pekerjaan Tuhan! 
				Sebab kamu tahu, bahwa dalam persekutuan dengan Tuhan jerih payahmu tidak sia-sia".
				<br />- 1 Korintus 15:58
			</blockquote> 
			<br />
			<br />Tuhan memberkati kita semua,
			<br />
			<br /><b><u>Ir. Agus Rahardja DS, MA Mis.</u></b>
			<br />Gembala Sidang CLC
		</div>
