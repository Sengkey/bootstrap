<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","musik");
?>
		<div id="content">
			<h1><a href="http://indonesia.christlivingchurch.com/musik" title="Pelayanan Musik">Tim Musik di Gereja CLC</a></h1>
			<div class="ministryimg"><img src="<?=Yii::app()->request->getBaseUrl(true)?>/images/ministry/praiseworship-singers.jpg" /></div>
			Tim Musik gereja CLC Sydney memulai pelayanan mereka sejak kebaktian Minggu CLC yang pertama di Peakhurst NSW. Tim musik ini terdiri 
			dari tim vokalis dan musisi yang mengasihi Allah dan mengasihi sesama. Kami menggunakan karunia, bakat dan kemampuan yang diberikan 
			Tuhan selama pelayanan ibadah kita. Tujuan akhir dari pelayanan kami adalah untuk membawa orang ke tahta Allah, mengundang kehadiran 
			Roh Kudus dan untuk mengalami suasana ibadah yang dinamis untuk gereja.
			<br /><br />
			Pada bulan Desember 2008, Tim Musik CLC dikenal sebagai Rise Up Music Ministry. Berkomitmen untuk memberikan yang terbaik. Sebagai 
			sebuah inisiatif baru, kami juga telah membuat dan menyiapkan sumber daya di 
			<a href="http://www.riseupmusic.com" target="_blank">www.riseupmusic.com</a> di mana Anda dapat menemukan informasi tentang pujian dan 
			penyembahan untuk mempelajari lebih lanjut tentang koordinator kepala, pemimpin tim dan berbagai kesempatan untuk Anda untuk melayani 
			Tuhan bersama kami melalui vokal dan musik.
			<br /><br />
			Kami percaya bahwa tim ini bahkan akan lebih diurapi dan diberdayakan untuk memberikan semangat keunggulan dalam setiap sesi ibadah, 
			berkomitmen untuk tim, untuk melakukan yang terbaik dan berkat bagi jemaat oleh kasih karunia Allah.
			<br /><br />
			<a name="peran"></a>
			<h2><a href="http://indonesia.christlivingchurch.com/musik#peran" title="Peran">Peran</a></h2>
			<ul>
				<li>
					<b>Vokalis</b>
					<br />
					Peran ini adalah untuk orang-orang yang memiliki pengalaman dalam bernyanyi, terutama di atas panggung. Jika Anda mampu bernyanyi 
					dengan harmonis dan / atau bisa menyanyi solo saat dibutuhkan, peran ini sangat cocok untuk Anda.
					<br />
					<b><em>» Kami menyediakan pelatihan</em></b>
					<br /><br />
					<div class="contact">Jika Anda tertarik untuk melayani di kapasitas ini, Anda bisa menghubungi Selly di 
						<a href="mailto:music@clc.asn.au?subject=I%20am%20interested%20to%20join%20CLC%20Vocalists%20Team">music@clc.asn.au</a>; 
						Audisi diperlukan.
					</div>
					<br />
				</li>
				<li>
					<b>Musisi</b>
					<div class="ministryimg"><img src="<?=Yii::app()->request->getBaseUrl(true)?>/images/ministry/praiseworship-drum.jpg" /></div>
					<br />
					Peran ini adalah untuk Anda yang memiliki pengalaman dalam memainkan berbagai alat musik. Anda akan harus menunjukkan bakat yang 
					memadai di bidang musik. Selain memainkan alat musik Anda berdasarkan akord dan lembaran musik, bermain oleh 
					telinga (keterampilan pendengaran) juga sangat dianjurkan. Gunakan dan kembangkan karunia dan talenta yang Tuhan telah berikan 
					kepada Anda. Anda akan perlu untuk terus mengembangkan keterampilan musik Anda dan teknik di luar waktu latihan tim. Namun, 
					perlu dicatat bahwa Tim Musik CLC tidak hanya membutuhkan keterampilan musik saja tetapi juga komitmen yang tinggi.
					<br />
					<b><em>» Kami menyediakan pelatihan</em></b>
					<br /><br />
					<div class="contact">Jika Anda tertarik untuk melayani di kapasitas ini, Anda bisa menghubungi riF di 
						<a href="mailto:music@clc.asn.au?subject=I%20am%20interested%20to%20join%20CLC%20Musicians%20Team">music@clc.asn.au</a>; 
						Audisi diperlukan.
					</div>
					<br />
				</li>
				<li>
					<b>Tim Koor</b>
					<br />
					Paduan suara koor terbuka untuk Anda yang suka menyanyi. Kami sering memiliki paduan suara untuk acara tahunan kami.
					<br />
					<b><em>» Kami menyediakan pelatihan</em></b>
					<br /><br />
					<div class="contact">Anda dapat menghubungi 
						<a href="mailto:music@clc.asn.au?subject=I%20am%20interested%20to%20join%20CLC%20Choir%20Team">music@clc.asn.au</a> untuk 
						informasi lebih lanjut menjadi anggota koor CLC untuk acara berikutnya; 
						Audisi tidak diperlukan.
					</div>
				</li>
			</ul>
			<br /><br />
			<blockquote class="verse">
				Nyanyikanlah bagi-Nya nyanyian baru; petiklah kecapi baik-baik dengan sorak-sorai!
				<br />- Mazmur 33:3
			</blockquote>
		</div>
