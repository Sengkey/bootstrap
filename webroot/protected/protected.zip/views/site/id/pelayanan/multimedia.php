<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","multimedia");
?>
		<div id="content">
			<h1><a href="http://indonesia.christlivingchurch.com/multimedia" title="Multimedia">Multimedia di Gereja CLC</a></h1>
			Tim Multimedia di gereja CLC Sydney memulai pelayanan mereka sejak kebaktian CLC yang pertama di Peakhurst, NSW. Tim ini bertujuan 
			untuk melayani Tuhan dengan semua talenta yang berhubungan seperti informasi dan teknologi, desain dan multimedia. Orang yang bekerja 
			di tim ini memberikan semua kemampuan terbaik mereka untuk membuat setiap acara dalam melayani Tuhan lancar terutama di Kebaktian Umum 
			untuk menarik orang yang masih belum mengenal Allah kemudian membawa mereka ke tahta Allah.
			<br /><br />
			<a name="peran"></a>
			<h2><a href="http://indonesia.christlivingchurch.com/multimedia#peran" title="Peran">Peran</a></h2>
			<ul>
				<li>
					<b>Operator Kebaktian Minggu</b>
					<br />
					Peran ini digunakan untuk menyusun lirik lagu, mengoperasikan peralatan multimedia dan menyajikannya di kebaktian Minggu. 
					Lirik lagu disusun dalam dua bahasa yaitu Indonesia dan Inggris.
				</li>
				<li>
					<b>Publikasi</b>
					<br />
					Peran ini digunakan untuk mempublikasikan aktivitas yang gereja CLC miliki di setiap hari. Ini bertujuan untuk menarik orang 
					lain dengan memberikan layout presentasi yang baik yang disebut "Warta". Di dalamnya, ada banyak artikel baik tentang Kristen 
					dan renungan harian.
				</li>
				<li>
					<b>Tim Kreatif dan Video</b>
					<br />
					Peran ini dijalankan bersama tim untuk menangani kreativitas dan bakat dalam melayani Tuhan seperti membuat penampilan drama dan gereja.
				</li>
			</ul>
			<br />
			<a name="lowongan"></a>
			<h2><a href="http://indonesia.christlivingchurch.com/multimedia#lowongan" title="Lowongan">Lowongan Pelayanan</a></h2> 
			Kami sekarang merekrut relawan dengan ketentuan sebagai berikut:
			<ul>
				<li>
				harus memiliki hubungan pribadi dengan Yesus Kristus
				</li> <li>
				harus menghadiri kebaktian Gereja Christ Living Church secara teratur
				</li>
			</ul>
			<b><em>» Kami menyediakan pelatihan</em></b>
			<br /><br />
			<div class="contact">Jika Anda tertarik, silakan 
				<a href="mailto:multimedia@christlivingchurch.com?subject=I%20am%20interested%20to%20join%20CLC%20Multimedia%20Team">hubungi kami 
					melalui email di sini</a>
			</div>
			<br /><br />
			<blockquote class="verse">
				Jangan hanya di hadapan mereka saja untuk menyenangkan hati orang, tetapi sebagai hamba-hamba Kristus yang dengan segenap hati 
				melakukan kehendak Allah, dan yang dengan rela menjalankan pelayanannya seperti orang-orang yang melayani Tuhan dan bukan manusia.
				<br />- Efesus 6:6-7 (TB)
			</blockquote>
		</div>
