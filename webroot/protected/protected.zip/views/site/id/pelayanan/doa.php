<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","doa");
?>
		<div id="content">
			<h1><a href="http://indonesia.christlivingchurch.com/doa" title="Pelayanan Doa">Pelayanan Doa di Gereja CLC</a></h1>
			Di gereja CLC Sydney, kami percaya pada kekuatan doa baik untuk mendukung pelayanan atau setiap aspek kehidupan kita sehari-hari. 
			Doa adalah inti dari hubungan kita dengan Allah, karena itu adalah jalan bagi kita untuk terhubung dan berkomunikasi dengan Tuhan. 
			Doa adalah karunia Tuhan kepada kita.
			<br /><br />
			<a name="persekutuandoa"></a>
			<h2><a href="http://indonesia.christlivingchurch.com/doa#persekutuandoa" title="Persekutuan Doa">Persekutuan Doa</a></h2>
			Kami percaya bahwa persekutuan doa merupakan bagian penting dari kehidupan gereja yang merupakan bagian tak terpisahkan dari 
			pelayanan lainnya. Doa adalah "alat" yang ampuh untuk menerobos masalah Anda dan sebuah gerbang untuk menerima berkat Surga berlimpah. 
			Jadi, jangan pernah lewatkan persekutuan doa kami yang diadakan pada:
			<br /><br />
			<ul>
				<li>
					<b>Waktu:</b> Setiap Sabtu, 16:30 - kecuali minggu ke-5
				</li>
				<li>
					<b>Alamat:</b> 57 Princes Hwy, Kogarah
				</li>
			</ul>
			<br />
			<a name="permohonandoa"></a>
			<h2><a href="http://indonesia.christlivingchurch.com/doa#permohonandoa" title="Permohonan Doa">Permohonan Doa</a></h2>
			Jika Anda memiliki masalah atau apa yang perlu didukung, jangan ragu untuk menghubungi kami atau mengirimkan permintaan doa Anda. 
			Kami akan menjadikan permintaan Anda menjadi bagian dalam doa kita.
			<br />
			Mari kita mengalami kesembuhan dan mukjizat dengan kami.
			<br />
			Nikmati hidup berkemenangan Anda dengan kasih karunia Allah dalam Yesus Kristus Tuhan.
			<br /><br />
			<hr />
			<br />
			<strong>Note:</strong> Mohon informasikan kami dengan detail mengenai hal apa yang dapat kami doakan untuk Anda.
			<br /><br />
			<strong>Contoh yang kurang detail:</strong> Tolong doakan persoalan saya
			<br /><br />
			<strong>Contoh yang detail:</strong> Tolong dukung saya dalam doa karena saya saat ini sedang sakit punggung, 
			padahal saya harus memimpin pujian pertama kali minggu depan.
			<br /><br />
			<hr />
			<br />

<div class="ce_form block">
	<form action="doa" id="f1" method="post" enctype="application/x-www-form-urlencoded">
	<div class="formbody">
	<table cellspacing="0" cellpadding="0" summary="Form fields">
		<tr class="row_0 row_first even">
			<td class="col_0 col_first"><label for="ctrl_1">Title:</label></td>
			<td class="col_1 col_last"><select name="Title" id="ctrl_1" class="select"><option value="Mr.">Mr.</option><option value="Mrs.">Mrs.</option><option value="Miss">Miss</option></select></td>
		</tr>
		<tr class="row_1 odd">
			<td class="col_0 col_first"><label for="ctrl_2" class="mandatory">First Name:</label><span class="mandatory">*</span></td>
			<td class="col_1 col_last"><input type="text" name="First_Name" id="ctrl_2" class="text mandatory" value="" maxlength="15" /></td>
		</tr>
		<tr class="row_2 even">
			<td class="col_0 col_first"><label for="ctrl_3" class="mandatory">Last Name:</label><span class="mandatory">*</span></td>
			<td class="col_1 col_last"><input type="text" name="Last_Name" id="ctrl_3" class="text mandatory" value="" maxlength="15" /></td>
		</tr>
		<tr class="row_3 odd">
			<td class="col_0 col_first"><label for="ctrl_4" class="email mandatory">Email Address:</label><span class="mandatory">*</span></td>
			<td class="col_1 col_last"><input type="text" name="Email_Address" id="ctrl_4" class="text email mandatory" value="" /></td>
		</tr>
		<tr class="row_4 even">
			<td class="col_0 col_first"><label for="ctrl_6" class="mandatory">Content</label><span class="mandatory">*</span></td>
			<td class="col_1 col_last"><textarea name="Comments" id="ctrl_6" class="textarea mandatory" rows="8" cols="40"></textarea></td>
		</tr>
		<tr class="row_5 row_last odd">
			<td class="col_0 col_first"><label for="ctrl_7">Security Question:</label><span class="mandatory">*</span></td>
			<td class="col_1 col_last"><input type="text" name="cf38fb090c0c0617316a4c061cd16cdc4" id="ctrl_7" class="captcha" value="0" maxlength="2" /> <input type="submit" id="ctrl_7_submit" class="submit" value="Submit" /> <span class="captcha_text">What is the sum of 5 and 9?</span></td>
		</tr>
	</table>
	</div>
	</form>
</div>

			<br /><br />
			<blockquote class="verse">
				Janganlah hendaknya kamu kuatir tentang apapun juga, tetapi nyatakanlah dalam segala hal keinginanmu kepada Allah dalam doa 
				dan permohonan dengan ucapan syukur. Damai sejahtera Allah, yang melampaui segala akal, akan memelihara hati dan pikiranmu 
				dalam Kristus Yesus.
				<br />- Filipi 4:6-7 (TB)
			</blockquote>
		</div>
