<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","dekorasi");
?>
		<div id="content">
			<h1><a href="http://indonesia.christlivingchurch.com/dekorasi" title="Dekorasi Gereja">Dekorasi Gereja</a></h1>
			<div class="ministryimg"><img src="<?=Yii::app()->request->getBaseUrl(true)?>/images/ministry/stagedesign.jpg" /></div>Tim Dekorasi gereja CLC Sydney menyediakan pencahayaan untuk panggung & acara serta dekorasi bagi kebaktian CLC. Kami adalah satu tim yang berbagi semangat yang sama dan menggunakan kreativitas untuk menggabungkan dekorasi panggung dan cahaya alami dan buatan ke dalam simfoni seni visual untuk membantu mengkomunikasikan pesan Injil kepada setiap anggota CLC.
			<br /><br />
			<a name="lowongan"></a>
			<h2><a href="http://indonesia.christlivingchurch.com/dekorasi#lowongan" title="Lowongan">Lowongan Pelayanan</a></h2> 
			Kami sekarang merekrut relawan dengan ketentuan sebagai berikut:
			<ul>
				<li>
					harus memiliki hubungan pribadi dengan Yesus Kristus
				</li>
				<li>
					harus menghadiri kebaktian Gereja Christ Living Church secara teratur
				</li>
				<li>
					harus memiliki kemampuan untuk desain, seni dan warna
				</li>
				<li>
					harus kreatif, antusias dan ORIGINAL!!!
				</li>
			</ul>
			<b><em>» Kami menyediakan pelatihan</em></b>
			<br /><br />
			<div class="contact">Jika Anda adalah salah satu dari orang-orang berbakat dan berbakat dan tertarik bergabung dalam Tim Dekorasi CLC, jangan ragu untuk <a href="mailto:stagedesign@clc.asn.au?subject=I%20am%20interested%20to%20join%20CLC%20Stage%20Design%20Team">menghubungi kami</a> dan bersama-sama kita akan membuat Gereja CLC sebuah gereja lebih berwarna dan menyenangkan!!!
			</div>

			<br /><br />
			<blockquote class="verse">
				Dan rumah yang hendak kudirikan itu harus besar, sebab Allah kami lebih besar dari segala allah. Tetapi siapa yang mampu mendirikan suatu rumah bagi Dia, sedangkan langit, bahkan langit yang mengatasi segala langitpun tidak dapat memuat Dia? Dan siapakah aku ini, sehingga aku hendak mendirikan suatu rumah bagi Dia, kecuali sebagai tempat untuk membakar korban di hadapan-Nya? Maka sekarang, kirimlah kepadaku seorang yang ahli mengerjakan emas, perak, tembaga, besi, kain ungu muda, kain kirmizi, kain ungu tua, dan yang juga pandai membuat ukiran, untuk membantu para ahli yang ada padaku di Yehuda dan di Yerusalem, yang telah ditunjuk ayahku Daud.
				<br />- 2 Tawarikh 2:5-7
			</blockquote>
		</div>
