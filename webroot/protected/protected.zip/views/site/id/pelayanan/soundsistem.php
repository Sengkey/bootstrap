<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","soundsistem");
?>
		<div id="content">
			<h1><a href="http://indonesia.christlivingchurch.com/soundsistem" title="Pelayanan Sound Sistem">Pelayanan Sound Sistem di Gereja CLC</a></h1>
			<div class="ministryimg"><img src="<?=Yii::app()->request->getBaseUrl(true)?>/images/ministry/soundsystem.jpg" /></div>Tim Sound Sistem gereja CLC Sydney bertujuan untuk memuliakan Tuhan Yesus Kristus dengan menyediakan layanan suara berkualitas untuk 
			pembicara, vokalis dan tim musik, sehingga setiap pesan dalam kata atau lagu akan jelas didengar dan dimengerti.
			<br /> <br />
			Sangat penting untuk menghasilkan suara yang solid, mengingat sebagian besar pelayanan di CLC terlibat dengan audio. 
			Suara dari pemimpin pujian, penyanyi, paduan suara dan pembicara perlu didengar dengan kualitas baik melalui speaker untuk memberikan 
			dampak yang lebih kepada jemaat. Selain itu, kita perlu suara yang jernih dan jelas untuk memastikan setiap orang di gedung mampu 
			mendengar setiap kata dengan jelas diucapkan oleh pembicara CLC. Tim Sound Sistem CLC akan memberikan hasil yang terbaik melalui 
			keahlian disertai sikap sukacita dan kesabaran.
			<br /><br />
			<a name="peran"></a>
			<h2><a href="http://indonesia.christlivingchurch.com/soundsistem#peran" title="Peran">Peran</a></h2>
			<ul>
				<li>
					<b>Teknisi Sound Sistem</b>
					<br />
					Ini adalah peran awal untuk melayani di Tim Sound Sistem CLC, yaitu bertanggung jawab untuk memastikan bahwa setiap mikrofon bekerja 
					dengan benar, dipasang ke tempat yang tepat di multicore dan papan suara. Untuk memastikan semua kabel mikrofon tersusun dengan rapi. 
					Jika diperlukan, Teknisi Sound Sistem mengatur mikrofon dan stan mikrofon selama kebaktian untuk memfasilitasi mengambil suara terbaik 
					dengan gangguan paling minim.
					<br /><br />
					Teknisi Sound ini juga bertanggung jawab untuk pengujian, identifikasi dan perbaikan atau penggantian kabel yang salah, 
					seperti yang diarahkan oleh Ahli Teknik Suara. Teknisi Sound juga mengharuskan untuk memiliki "telinga untuk mendengar" karena suara 
					yang jernih sangat penting!
					<br /><br />
					<div class="contact">Jika Anda tertarik untuk melayani di bidang ini, silakan 
						<a href="mailto:worship@clc.asn.au?subject=I%20am%20interested%20to%20join%20CLC%20Sound%20Team">hubungi kami melalui email di sini</a>
					</div>
					<br />
				</li>
				<li>
					<b>Ahli Teknik Suara</b>
					<br />
					Ahli Teknik Suara adalah orang yang telah menunjukkan kompetensi dalam jenis peralatan dalam sistem suara dan fungsinya, menggabungkan 
					komponen-komponen sound system untuk memberikan suara yang terbaik ke pendengar, mengerti akan tingkatan frekuensi yang diperlukan untuk 
					sebuah ruangan berhubungan dengan pengaturan peralatan suara, bagaimana memecahkan berbagai masalah suara melalui perawatan akustik, EQ, 
					penempatan speaker dan masih banyak lagi.
					<br /><br />
					Peran ini juga bertanggung jawab untuk pelatihan dan semua kontrol kualitas pelayanan. Mengevaluasi kinerja sistem dalam basis mingguan, 
					memperbaiki masalah dan menyesuaikan desain akustik jika perlu.
					<br /><br />
					<div class="contact">Jika Anda tertarik untuk melayani di bidang ini, silakan 
						<a href="mailto:worship@clc.asn.au?subject=I%20am%20interested%20to%20join%20CLC%20Sound%20Team">hubungi kami melalui email di sini</a>
					</div>
				</li>
			</ul>
		</div>
