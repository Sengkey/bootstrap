<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","perpustakaan");
?>
		<div id="content">
			<h1><a href="http://indonesia.christlivingchurch.com/perpustakaan" title="Perpustakaan">Perpustakaan Gereja CLC</a></h1>
			<div class="ministryimg"><img src="<?=Yii::app()->request->getBaseUrl(true)?>/images/ministry/library.jpg" /></div>Perpustakaan di gereja CLC Sydney beroperasi sebagai tempat penyimpanan pengetahuan dan informasi. Perpustakaan CLC bertumbuh dan 
			berkembang dalam koleksi sumber daya cukup mantap. Kami mengucapkan terima kasih kepada semua donatur yang telah membantu.
			<br /><br />
			Kami sekarang telah berhasil menjadikan pelayanan ini sebagai titik repositori dan akses untuk cetak, audio, dan materi visual dalam 
			berbagai format, termasuk peta, buku, dokumen, rekaman audio / kaset, CD, kaset video, DVD rohani (berdasarkan iman Kristen) dan beberapa tambahan dari sumber-sumber spiritual bukan seperti buku-buku tentang resep masakan, rumah dekorasi interior, dll
			<br /><br />
			Berbeda dengan perpustakaan yang biasanya membutuhkan situasi yang tenang, kami memiliki situasi yang positif dan menyenangkan di aula 
			gereja yang sibuk. Anda akan bersenang-senang berada di sini melayani atau memilih sumber daya yang akan Anda pinjam.
			<br /><br />
			Kami menerima sumbangan sumber daya yang berguna untuk membantu perluasan koleksi Perpustakaan. Jenis sumber daya bisa buku, kaset 
			audio / kaset, CD, kaset video, DVD.
			<br /><br />
			<a name="peran"></a>
			<h2><a href="http://indonesia.christlivingchurch.com/perpustakaan#peran" title="Peran">Peran</a></h2>
			<ul>
				<li>
					Untuk memberikan layanan bermanfaat ramah dan sumber daya bermanfaat yang mendukung prestasi dalam membantu jemaat untuk bertumbuh secara rohani, dan untuk mendapatkan pengetahuan lebih, keterampilan, dan kemampuan untuk meningkatkan kualitas hidup mereka.
				</li>
				<li>
					Untuk menyimpan dan meminjamkan buku atau jenis sumber daya untuk periode waktu tertentu untuk membantu orang-orang yang memilih untuk tidak, atau tidak mampu untuk membeli sendiri.
				</li>
				<li>
					Untuk mendorong jemaat untuk membaca lebih banyak buku.
				</li>
				<li>
					Untuk membangun hubungan baik dan lebih dekat di antara jemaat yang melayani di Perpustakaan dan jemaat yang meminjam sumber daya.
				</li>
				<li>
					Untuk melatih kerjasama tim yang baik yang melayani di Perpustakaan.
				</li>
			</ul>
			<br />
			<a name="lowongan"></a>
			<h2><a href="http://indonesia.christlivingchurch.com/perpustakaan#lowongan" title="Lowongan">Lowongan Pelayanan</a></h2> 
			Kita sekarang merekrut relawan dengan ketentuan sebagai berikut:
			<ul>
				<li>
					harus memiliki hubungan pribadi dengan Yesus Kristus
				</li>
				 <li>
					harus menghadiri kebaktian Gereja Christ Living Church secara teratur
				</li>
				 <li>
					harus memiliki kepribadian yang baik, bahagia, ramah, membantu
				</li>
				 <li>
					ingin melayani orang lain
				</li>
				 <li>
					(opsional) memiliki tulisan tangan yang rapi dan baik 
				</li>
			</ul>
			<b><em>» Kami menyediakan pelatihan</em></b>
			<br /><br />
			<div class="contact">Untuk relawan dan atau memberikan sumbangan, Anda dapat <a href="mailto:admin@christlivingchurch.com?subject=About%20the%20CLC%20Library%20Ministry">menghubungi kami melalui email di sini</a></div>
		</div>
