<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","website");
?>
		<div id="content">
			<h1><a href="http://indonesia.christlivingchurch.com/website" title="Pelayanan Website">Pelayanan Website</a></h1>
			Di Christ Living Church, kami menggunakan Internet untuk menjangkau jiwa dengan menyebarkan Kabar Baik akan keselamatan dari Allah dan 
			untuk berinteraksi dengan pengguna. Tujuan utama dari website CLC adalah:
			<ul>
				<li>
					Untuk memberikan informasi akan Christ Living Church kepada mereka yang sedang mencari gereja untuk menetap
				</li>
				<li>
					Untuk memberikan informasi akan pelayanan dan aktivitas di CLC yang tersedia
				</li>
				<li>
					Untuk membantu pengguna bertumbuh secara rohani dengan menyediakan materi tambahan pelayanan dan kebaktian seperti kotbah online 
					gratis, catatan, renungan harian dan sebagainya
				</li>
			</ul>
			<br />
			<a name="sukarela"></a>
			<h2><a href="http://indonesia.christlivingchurch.com/website#sukarela" title="Sukarela">Lowongan untuk Pelayanan</a></h2> 
			Kami sekarang mengajak Anda untuk melayani bersama di CLC di bidang website dengan persyaratan:
			<ul>
				<li>
					harus mempunyai hubungan personal dengan Yesus Kristus
				</li>
				<li>
					harus menghadiri kebaktian Gereja Christ Living Church secara teratur
				</li>
				<li>
					harus setidaknya berumur 16 tahun
				</li>
				<li>
					harus mempunyai keinginan untuk mempelajari cara membuat website atau desain
				</li>
			</ul>
			<b><em>» Kami menyediakan pelatihan</em></b>
			<br /><br />
			<div class="contact">Jika Anda tertarik, silakan 
				<a href="mailto:admin@christlivingchurch.com?subject=I%20am%20interested%20to%20join%20CLC%20Website%20Team">hubungi kami melalui 
					email di sini</a>
			</div>
		</div>
