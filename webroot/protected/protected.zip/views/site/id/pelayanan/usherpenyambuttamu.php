<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","usherpenyambuttamu");
?>
		<div id="content">
			<h1><a href="http://indonesia.christlivingchurch.com/usherpenyambuttamu" title="Tim Usher dan Penyambut Tamu">Tim Usher & Penyambut Tamu di Gereja CLC</a></h1>
			Tim Usher gereja CLC Sydney adalah pelopor, karena mereka adalah yang pertama menyambut orang yang datang ke gereja yang kadang terbebani, 
			sedih atau putus asa. Tim ini menyapa mereka dengan senyum yang menyenangkan, sambutan hangat dan mengantar mereka ke kursi yang nyaman. 
			Pelayanan ini adalah penting karena ini memastikan bahwa jemaat yang datang melihat dan mengalami kasih Tuhan sebelum kebaktian dimulai.
			<br /><br />
			<a name="peran"></a>
			<h2><a href="http://indonesia.christlivingchurch.com/usherpenyambuttamu#peran" title="Peran">Peran</a></h2>
			<ul>
				<li>
					menyapa, membuat setiap usaha untuk membantu jemaat yang datang untuk merasa diterima dan nyaman
				</li>
				<li>
					mengarahkan jemaat ke tempat duduk mereka
				</li>
				<li>
					mendistribusikan materi yang berhubungan dengan CLC (buletin warta, kartu selamat datang, kartu informasi, dll)
				</li>
				<li>
					membagikan kantong persembahan kepada jemaat
				</li>
				<li>
					berurusan dengan keadaan darurat yang mungkin timbul, atau menghubungi orang yang diperlukan untuk memberikan bantuan yang tepat
				</li>
			</ul>
			<br /><br />
			<a name="lowongan"></a>
			<h2><a href="http://indonesia.christlivingchurch.com/usherpenyambuttamu#lowongan" title="Lowongan">Lowongan Pelayanan</a></h2> 
			<br />
			Kami sekarang merekrut relawan dengan ketentuan sebagai berikut:
			<ul>
				<li>
					harus memiliki hubungan pribadi dengan Yesus Kristus
				</li>
				<li>
					harus menghadiri kebaktian Gereja Christ Living Church secara teratur
				</li>
				<li>
					harus memiliki kerendahan hati untuk melayani Dia
				</li>
			</ul>
			<b><em>» Kami menyediakan pelatihan</em></b>
			<br /><br />
			<div class="contactbyphone">Jika Anda tertarik, silakan hubungi <br />Arif di <a href="mailto:service-coordinator@clc.asn.au">service-coordinator@clc.asn.au</a> atau Yuli di 0423339553</div>
			<br /><br />
			<blockquote class="verse">
				Mari, pujilah TUHAN, hai semua hamba TUHAN, yang datang melayani di rumah TUHAN pada waktu malam.
				<br />- Mazmur 134:1
			</blockquote>
		</div>
