<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","makanan-minuman");
?>
		<div id="content">
			<h1><a href="http://indonesia.christlivingchurch.com/makanan-minuman" title="Makanan dan Minuman">
			<div class="ministryimg"><img src="<?=Yii::app()->request->getBaseUrl(true)?>/images/ministry/foodbeverage.jpg" /></div>Pelayanan Penyedia Makanan dan Minuman di CLC</a></h1>
			Misi dari Pelayanan Penyedia Makanan dan Minuman adalah untuk membagikan kasih Yesus Kristus dengan memberi perhatian tidak hanya 
			kepada kebutuhan rohani, tetapi juga kebutuhan praktis gereja.
			<br /><br />
			Pelayanan ini bertanggung jawab untuk menyiapkan makanan untuk kegiatan gereja CLC Sydney, seperti kebaktian, 
			<a href="http://indonesia.christlivingchurch.com/pemuridan-pelatihan.html">kelas pengajaran dan pendalaman Alkitab</a> dan setiap 
			acara khusus lainnya. Departemen ini juga tersedia untuk membantu dengan resepsi pernikahan Anda atau makan malam latihan.
			<br /><br />
			<a name="lowongan"></a>
			<h2><a href="http://indonesia.christlivingchurch.com/makanan-minuman#lowongan" title="Lowongan">Lowongan Pelayanan</a></h2> 
			Kita sekarang merekrut relawan dengan ketentuan sebagai berikut:
			<ul>
				<li>
					harus memiliki hubungan pribadi dengan Yesus Kristus
				<li>
					harus menghadiri kebaktian Gereja Christ Living Church secara teratur
				<li>
					harus memiliki hati untuk melayani orang lain
				<li>
					harus memiliki semangat untuk belajar tentang memasak
				</li>
			</ul>
			<b><em>» Kami menyediakan pelatihan</em></b>
			<br /><br />
			<div class="contact">Jika Anda tertarik, silakan 
				<a href="mailto:admin@christlivingchurch.com?subject=I%20am%20interested%20to%20join%20CLC%20Food%20Beverage%20Team">hubungi kami 
					melalui email di sini</a>
			</div>
			<br /><br />
			<blockquote class="verse">
			Jauhkanlah dari padaku kecurangan dan kebohongan. Jangan berikan kepadaku kemiskinan atau kekayaan. Biarkanlah aku menikmati makanan 
			yang menjadi bagianku<br />- Amsal 30:8 (TB)
			</blockquote>
		</div>
