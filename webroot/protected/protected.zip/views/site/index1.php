<?php $this->pageTitle=Yii::app()->name; ?>
<!--
		<div id="slideshow">
			<img src="<?php echo Yii::app()->request->getBaseUrl(true); ?>/images/slideshowdummy.jpg" />
		</div>
-->
		<div id="content">
			This will be the content of this page
			<br /><br />
			<select style="border:3px;outline:none;">
				<option>AAA</option>
				<option>BBB</option>
			</select>
		</div>
