<?php $this->pageTitle=Yii::app()->name; ?>
<!--
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=246290772075137";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
-->

<div id="topbar">
	<div class="socials">
		<div style="margin-top:3px;float:left;">
			Change language: <img src="<?=Yii::app()->request->getBaseUrl(true)?>/images/lang_en.jpg" alt="language en" title="english" style="margin-bottom:-3px;"> - <a href="<?=Yii::app()->request->getBaseUrl(true)."/".$data['en-url']?>" style="font:12px Verdana,Arial,Tahoma;"><?=$data['en-lang']?></a> | 
			<img src="<?=Yii::app()->request->getBaseUrl(true)?>/images/lang_id.jpg" alt="language id" title="indonesian" style="margin-bottom:-3px;"> - <a href="<?=Yii::app()->request->getBaseUrl(true)."/".Yii::app()->params['id-url']."/".$data['id-url']?>" style="font:12px Verdana,Arial,Tahoma;"><?=$data['id-lang']?></a>
		</div>
<!--
		<div style="float:right;width:210px;">
			<a href="https://twitter.com/clcaustralia" class="twitter-follow-button" data-show-count="true">Follow @clcaustralia</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
		</div>
		<div style="float:right;margin:2px 5px 0 0;">
			<div class="fb-like" data-href="http://www.facebook.com/christlivingchurch" data-layout="button_count" data-send="false" data-width="50" data-show-faces="false"></div>
		</div>
		<div style="float:right;margin:2px 0 0 0;width:70px;">
			<script>document.write("<g:plusone size='medium' callback='http://www.christlivingchurch.com' href='http://www.christlivingchurch.com'></g:plusone>");</script>
		</div>
-->
	</div>
</div>

<div id="container">
	<script type='text/javascript' src='<?=Yii::app()->request->getBaseUrl(true)?>/js/index.js'></script>
	<div id="main">

<?php $this->renderPartial($data['tpl'],array("data"=>$data));?>

	</div>
	<div class="clear"></div>

	<div id="page">
		<div id="footer">
			<div class="column1">
				<h3>Main Links</h3>
				<ul>
					<li class="footermenu footermenuabout"><span class="arrow">&raquo;</span>About CLC</li>
					<li class="footermenu footermenusundayservice"><span class="arrow">&raquo;</span>Sunday Service</li>
					<li class="footermenu footermenudiscipleshiptraining"><span class="arrow">&raquo;</span>Discipleship Training</li>
					<li class="footermenu footermenuministry"><span class="arrow">&raquo;</span>Ministry</li>
					<li class="footermenu footermenuonlinesermon"><a href="<?=Yii::app()->request->getBaseUrl(true)?>/sermon">Online Sermon</a></li>
					<li class="footermenu footermenuloveoffering"><a href="<?=Yii::app()->request->getBaseUrl(true)?>/offering">Love Offering</a></li>
					<li class="footermenu footermenuphotogallery"><span class="arrow">&raquo;</span>Photo Gallery</li>
					<li class="footermenu footermenucontactus"><span class="arrow">&raquo;</span>Contact Us</li>
				</ul>
			</div>
			<div class="column2">
				<div class="footersubmenu">
					<div class="footersubmenuoptions footersubmenuministry">
						<h3>Ministry &raquo;</h3>
						<ul>
							<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/foodbeverage">Food & Beverage</a></li>
							<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/library">Library</a></li>
							<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/multimedia">Multimedia</a></li>
							<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/praiseworship">Praise & Worship</a></li>
							<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/prayer">Prayer</a></li>
							<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/soundsystem">Sound System</a></li>
							<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/stagedesign">Stage Design</a></li>
							<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/ushersgreeters">Ushers & Greeters</a></li>
						</ul>
						<ul>
							<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/website">Website</a></li>
						</ul>
					</div>
					<div class="footersubmenuoptions footersubmenusundayservice">
						<h3>Sunday Service &raquo;</h3>
						<ul>
							<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/#">Adults</a></li>
							<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/#">Children & Teens</a></li>
							<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/#">Youth (The Brigades)</a></li>
						</ul>
					</div>
					<div class="footersubmenuoptions footersubmenuabout">
						<h3>About CLC &raquo;</h3>
						<ul>
							<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/#">Directions</a></li>
							<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/visionmission">Vision & Mission</a></li>
							<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/whatwebelieve">What we believe</a></li>
							<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/corevalues">Core values</a></li>
							<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/strategy">Strategy</a></li>
							<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/history">History</a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="column3">
				<h3>Love Offering</h3>
				Bank: <b>Westpac Bank</b>
				<br />
				Acc. Name: <b>Christ Living Church Inc.</b>
				<br />
				BSB: <b>032275</b> | Acc. No: <b>187114</b>
				<br /><br />or transfer online:
				<br />
				<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
					<input type="hidden" name="cmd" value="_s-xclick">
					<input type="hidden" name="hosted_button_id" value="V3QCG72PNBPY6">
					<input type="image" src="<?=Yii::app()->request->getBaseUrl(true)?>/images/donatebutton.png" border="0" name="submit" alt="PayPal — The safer, easier way to pay online.">
					<img alt="" border="0" src="https://www.paypalobjects.com/en_AU/i/scr/pixel.gif" width="1" height="1">
				</form>
			</div>
			<div class="column4">
				<h3>Send us a Message</h3>
				<form action="" method="post">
				<div class="formuser">
					<input type="text" class="name" name="name" />
				</div>
				<div class="formemail">
					<input type="text" class="email" name="email" />
				</div>
				<div class="formtype">
					<select class="type" name="type">
						<option value="0">-- Select Message Type --</option>
						<optgroup label="Message Types">
							<option value="1">Testimonial / Kesaksian</option>
							<option value="2">Prayer Request / Permohonan Doa</option>
							<option value="9">Others / Lainnya</option>
						</optgroup>
					</select>
					<!--<input type="text" class="type" name="type" />-->
				</div>
				<textarea></textarea>
				<input type="submit" />
				</form>
			</div>
			<div class="clear"></div>
			<div id="footernote">
				Copyright &copy; <?php echo date("Y");?> Christ Living Church<br><a href="http://www.seothatworks.com.au">SEO</a> by SEOthatworks
			</div>
		</div>
		<script type='text/javascript' src='<?=Yii::app()->request->getBaseUrl(true)?>/js/main.js'></script>
	</div>
</div>

<div id="headerarea">
	<div id="wrapper">
		<div id="header">
			<div id="countdown">
				<div class="nextsermontxt"><u><a href="#">Watch</a></u> LIVE Broadcast in:</div>
				<div id="timer">
<?php 
$duedate = "2014-01-01 00:00:00 GMT+10:00";
?>
					<span id='countdown1'><?=$duedate?></span>
					<br /><br /><b><small>Sunday, 01 Jan 2014 04PM AEST</small></b>
					<noscript><span class="digits" style="font:14px Arial,Verdana,Tahoma; color:#134173;"><b>Sunday, 01 Jan 2014 04PM AEST</b> <small>Sunday, 01 Jan 2014 04PM AEST</small></span></noscript>
				</div>
				<div class="text broadcastalert">
					<a href="http://www.christlivingchurch.com/sermon/livebroadcast/">
						<div>
							<span style="font-size:14px;">Our Main Service is </span><b>now LIVE<em>!</em></b>
							<br /><span style="font-size:14px;text-decoration:underline;">JOIN our Live Broadcast Service!</span>
						</div>
						<?php //if($clcevent) { echo "<br />".$clceventImg."<br />"; } ?>
					</a>

<?php 
/*

	<div class="text" id="timer" style="height:150px;">
<!--
<div style="font:700 14px Arial,Verdana;color:red;">There will be no Live Broadcast service for this week due to the Internet access difficulties for the live streaming. The video sermon for this week will still be published.</div>
-->
<script>document.write("<span id='countdown1'><?=$mynextServiceTime?></span>");</script>
<script>document.write('<br /><br /><?=$textLeftUntil?> <em>!</em><br /><?php echo $clcevent; ?><br /><b><?=$timeWithJavascript?></b>');</script>
<noscript><span class="digits" style="font:14px Arial,Verdana,Tahoma; color:#134173;"><b><?=$timeWithoutJS1?></b> <small><?=$timeWithoutJS2?></small></span></noscript>
</div>
<div class="text broadcastalert" style="text-align:center;">
<img src="http://www.christlivingchurch.com/home/clc_files/web2/images/alertdown.gif">
<a href="http://www.christlivingchurch.com/sermon/livebroadcast/" style="font:18px Verdana,Arial,Tahoma;color:#333;">
<div style="border:1px dotted #777;padding:5px 0;background:#ddd;">
<span style="font-size:14px;">Our Main Service is now</span>
<br /><b>Broadcasting LIVE<em>!</em></b>
<br /><span style="font-size:16px;text-decoration:underline;">JOIN our Live Broadcast Service!</span>
</div>
<?php if($clcevent) { echo "<br />".$clceventImg."<br />"; } ?>
</a>
</div>
*/
?>
				</div>
			</div>
			<div id="socialbuttons">
				<div id="fb"><a href="http://www.facebook.com/christlivingchurch" target="_blank"></a></div>
				<div id="tw"><a href="http://www.twitter.com/clcaustralia" target="_blank"></a></div>
			</div>
			<div id="headercontent">
				<img src="<?=Yii::app()->request->getBaseUrl(true)?>/images/bglogo.png" id="logobox" />
				<h1><a href="<?=Yii::app()->request->getBaseUrl(true)?>"><img src="<?=Yii::app()->request->getBaseUrl(true)?>/images/logo.png" id="logo" alt="Christ Living Church" /></a></h1>
				<div id="menu">
					<ul>
						<li id="about">
							<a href="<?=Yii::app()->request->getBaseUrl(true)?>/about">About CLC</a>
							<ul class="submenu about">
								<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/#">Directions</a></li>
								<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/visionmission">Vision & Mission</a></li>
								<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/whatwebelieve">What we believe</a></li>
								<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/corevalues">Core values</a></li>
								<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/strategy">Strategy</a></li>
								<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/history">History</a></li>
							</ul>
						</li>
						<li class="separator"></li>
						<li id="sundayservice">
							<a href="<?=Yii::app()->request->getBaseUrl(true)?>/sundayservice">Sunday Service</a>
							<ul class="submenu sundayservice">
								<li>Adults</li>
								<li>Children & Teens</li>
								<li>Youth (The Brigades)</li>
							</ul>
						</li>
						<li class="separator"></li>
						<li id="discipleship"><a href="<?=Yii::app()->request->getBaseUrl(true)?>/discipleshiptraining">Discipleship Training</a></li>
						<li class="separator"></li>
						<li id="ministry">
							<a href="<?=Yii::app()->request->getBaseUrl(true)?>/ministry">Ministry</a>
							<ul class="submenu ministry">
								<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/foodbeverage">Food & Beverage</a></li>
								<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/library">Library</a></li>
								<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/multimedia">Multimedia</a></li>
								<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/praiseworship">Praise & Worship</a></li>
								<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/prayer">Prayer</a></li>
								<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/soundsystem">Sound System</a></li>
								<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/stagedesign">Stage Design</a></li>
								<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/ushersgreeters">Ushers & Greeters</a></li>
								<li><a href="<?=Yii::app()->request->getBaseUrl(true)?>/website">Website</a></li>
							</ul>
						</li>
						<li class="separator"></li>
						<li id="onlinesermon"><a href="<?=Yii::app()->request->getBaseUrl(true)?>/sermon">Online Sermon</a></li>
						<li class="separator"></li>
						<li id="offering"><a href="<?=Yii::app()->request->getBaseUrl(true)?>/offering">Love Offering</a></li>
						<li class="separator"></li>
						<li id="gallery"><a href="<?=Yii::app()->request->getBaseUrl(true)?>/gallery">Photo Gallery</a></li>
						<li class="separator"></li>
						<li id="contact"><a href="<?=Yii::app()->request->getBaseUrl(true)?>/contact">Contact Us</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
