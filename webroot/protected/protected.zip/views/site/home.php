<?php $this->pageTitle=Yii::app()->name; ?>

		<link rel="stylesheet" type="text/css" href="<?=Yii::app()->request->getBaseUrl(true)?>/css/index.css" />
		<div id="slideshow">
			<img src="<?=Yii::app()->request->getBaseUrl(true)?>/images/slideshowdummy.jpg" />
			<img src="<?=Yii::app()->request->getBaseUrl(true)?>/images/slideshowdummy.jpg" />
			<img src="<?=Yii::app()->request->getBaseUrl(true)?>/images/slideshowdummy.jpg" />
			<img src="<?=Yii::app()->request->getBaseUrl(true)?>/images/slideshowdummy.jpg" />
			<img src="<?=Yii::app()->request->getBaseUrl(true)?>/images/slideshowdummy.jpg" />
		</div>
		<div id="content">
			<div class="columnthree">
				<div class="column1">
					<h2>Selamat Datang</h2>
					<span>
						<p>Gereja Indonesia di Sydney yang
						saling memberkati dan mengasihi
						dengan kasih Allah.</p>
						<br />
						<p>Selamat datang dan kami percaya
						Anda akan terberkati di gereja ini.</p>
						<br />
						<p>Tuhan memberkati!</p>
					</span>
				</div>
				<div class="column2">
					<a href="#"><img src="<?=Yii::app()->request->getBaseUrl(true)?>/images/index_groupphoto.jpg" /></a>
				</div>
				<div class="column3">
					<h2 style="line-height:35px;">Sambutan Gembala Sidang</h2>
					<span>
						<p>Shallom brothers & sisters in Christ of
						Christ Living Church Sydney</p>
						<br />
						<p>I'd like to give my thanks to Jesus Christ,
						as only by His grace we can celebrate
						the 6th anniversary of CLC in 2012 <span class="more"><a class="href">(more)</a></span></p>
					</span>
				</div>
			</div>
			<div class="clear"></div>
			<br />
			<div class="columnthree hotcolumn">
				<div class="column1">
					<h3>Sermon Online</h3>
					<a class="href"><img src="<?=Yii::app()->request->getBaseUrl(true)?>/images/menubottom-dummy.png" /></a>
					The quick brown fox jumps over the lazy dog. The quick brown fox jumps over the lazy dog
					<div class="readmore"><a href="#"></a></div>
				</div>
				<div class="separator"></div>
				<div class="column2">
					<h3>Praise & Worship</h3>
					<a class="href"><img src="<?=Yii::app()->request->getBaseUrl(true)?>/images/menubottom-dummy.png" /></a>
					The quick brown fox jumps over the lazy dog. The quick brown fox jumps over the lazy dog
					<div class="readmore"><a href="#"></a></div>
				</div>
				<div class="separator"></div>
				<div class="column3">
					<h3>Question & Answer</h3>
					<a class="href"><img src="<?=Yii::app()->request->getBaseUrl(true)?>/images/menubottom-dummy.png" /></a>
					The quick brown fox jumps over the lazy dog. The quick brown fox jumps over the lazy dog
					<div class="readmore"><a href="#"></a></div>
				</div>
			</div>
			<div class="rowseparator"></div>
			<div id="testimonials">
				<!--<h2>T<span><sup>estimonials</sup></span><div class="border"></div></h2>-->
				<h2>Testimonials</h2>
				<div class="testimonials">
					<div class="testimonial"><div class="txt">This is my testimonial 1<br /><div class="from">John</div></div></div>
					<div class="testimonial"><div class="txt">This testimonial is number 2<br /><div class="from">Mary</div></div></div>
					<div class="testimonial"><div class="txt">Testimonial 3 is this long<br /><div class="from">Jane</div></div></div>
					<div class="testimonial"><div class="txt">Here is the 4th testimonial<br /><div class="from">Mike</div></div></div>
					<div class="testimonial"><div class="txt">Testimonial 5, over and out<br /><div class="from">Ryonn</div></div></div>
				</div>
			</div>
		</div>
