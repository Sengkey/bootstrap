<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","offering");
?>
		<div id="content">
			<h1><a href="offering" title="Offering">Offering</a></h1>
			CLC congregation give their best offering to the Lord. This offering reflects our love to God who first loved us. 
			This is also the best opportunity to support the work of God in the CLC, that is to share the Good News to the whole world, 
			through the missionaries and the internet.
			<br /><br />
			CLC congregation bless for they are blessed, so our offering is done with joy and gratitude to God for all successes and 
			thanks are only by grace and the love of God. That is reflected in the prayer offerings below: 
			<br /><br />
			<center><em>
			"Blessed be thou O Lord, our Father, from everlasting to everlasting.
			<br /><br />O God, greatness, success, honor, glory and wealth are all Yours.
			<br /><br />Yes, everything in heaven and on earth, because wealth and honor come from You. And You hast power over all things.
			<br /><br />In Your hands, the power to expand and solidify everything. We love you, because You first loved us.
			<br /><br />You are the Lord who searches our hearts and delights in the sincerity of the heart. Therefore, we offer the best, with sincere heart and rejoice.
			<br /><br />In the name of Jesus we pray. Alleluia, Amen."
			</em></center>
			<br /><br />
			The offering in CLC is conducted as follows:
			<ul>
				<li>
					<b>Tithe Offering</b>. 
					The amount is at least 10% of the "take home pay" of the congregation's income.
				</li>
				<li>
					<b>Special Offering</b>. 
					There is no specific amount, but still represents the best offering of the heart that loves God.
				</li>
			</ul>
			<br />
			The offering can be placed directly into the offering bag during the weekly Sunday Service or transferred directly to:
			<br />
			<br /><b>Bank:</b> Westpac Bank
			<br /><b>Account Name:</b> Christ Living Church Incorporated
			<br /><b>BSB:</b> 032275
			<br /><b>Acc. No:</b> 187114
			<br /><br />
			All congregation's offering are managed by the CLC Financial Team led by Senior Treasurer. 
			CLC manages the congregation's offering by an open management system, meaning that each congregation has the right to see or 
			examine the validity of the financial books of CLC. To account for and ensure the validity of the financial statements of CLC, 
			at the end of each financial year, CLC books are audited by Public Accountant and reported to the Australian government as part 
			of the annual report of CLC service activity.
			<br /><br />
			The financial of CLC is fully utilized to fund operations and needed service facilities. 
			In addition, CLC also supports the mission service around the world in various fields, ie: 
			financing the spiritual seminars in Indonesia, financing the missionaries in the villages in Indonesia, 
			supporting the Bible Training Centre in Indonesia, providing scholarships for the less fortunate children, and many more.
			<br /><br />
			If you feel the need to support the CLC service of any type, please contact the Treasurer of CLC, namely: 
			Willy Ramlie (+61 433 186 702) or you can directly send your support to the CLC to the Bank account number mentioned above. 
			<br /><br />
			On behalf of the church congregation, we would like to thank you for your prayers and your best offering to the CLC service 
			for the glory of the name of the Lord Jesus Christ and the expansion of His Kingdom in the world.
			<br /><br />
			<blockquote class="verse">
				Therefore, my dear brothers and sisters, stand firm. Let nothing move you. Always give yourselves fully to the work of the Lord, 
				because you know that your labor in the Lord is not in vain.
				<br />- 1 Corinthians 15:58 (NIV)
			</blockquote>
			<br /><br />
			God bless us all,
			<br />
			<br /><b><u>Ir. Agus Rahardja DS, MA Mis.</u></b>
			<br />Senior Pastor
		</div>
