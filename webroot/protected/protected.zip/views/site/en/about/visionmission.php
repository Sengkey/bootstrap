<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","visionmission");
?>
		<div id="content">
			<h1><a href="visionmission" title="Vision">Vision</a></h1>
			Christ Living Church is:
			<ul>
				<li>
					A church of Jesus Christ
				</li>
				<li>
					Being a church with Biblical Mission oriented
				</li>
				<li>
					Focusing on The Words of God
				</li>
				<li>
					Becoming a local church with global impact 
				</li>
				<li>
					Being part of united Body of Christ   
				</li>
			</ul>
			<br />
			<h1><a href="visionmission" title="Mission">Mission</a></h1> 
			Christ Living Church is developing and mobilising their congregation:
			<ul>
				<li>
					to grow and get blessing in spirit, mind and body
				</li>
				<li>
					to obey The Great Commission (Mat. 28:19-20)
				</li>
				<li>
					to go mission and give impact to the world through technology and sending out the missionaries
				</li>
				<li>
					to do ministry complying with talents, gifts &amp; God’s calling
				</li>
				<li>
					to cooperate with other ministry networks
				</li>
			</ul>
		</div>
