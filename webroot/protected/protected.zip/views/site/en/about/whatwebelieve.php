<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","whatwebelieve");
?>
		<div id="content">
			<h1><a href="whatwebelieve" title="What we Believe">What we Believe</a></h1> 
			<ul>
				<li>
					<b>WE BELIEVE</b> in God, the Father Almighty, the Creator of humans, heaven and earth along with the world
				</li>
				<li>
					<b>WE BELIEVE</b> in Jesus Christ, his only Son, our Lord. Who was conceived by the 
					<a href="http://id.wikipedia.org/wiki/Holy_Ghost" target="_blank">Holy Ghost</a>, born of the 
					<a href="http://en.wikipedia.org/wiki/Mary_(mother_of_Jesus)" target="_blank">Virgin Mary</a>. Suffered under 
					<a href="http://en.wikipedia.org/wiki/Pontius_Pilate" target="_blank">Pontius Pilate</a>, was crucified, dead and buried: 
					He descended into hell. The third day He rose again from the dead; He ascended into 
					<a href="http://en.wikipedia.org/wiki/heaven" target="_blank">heaven</a>, and sits at the right hand of God the Father Almighty. 
					From thence he shall come to judge the quick and the dead.
				</li>
				<li>
					<b>WE BELIEVE</b> in the Holy Ghost, the holy church and the unity of the Body of Christ, the communion of saints, 
					the forgiveness of sins, the resurrection of the body, and the life everlasting.
				</li>
				<li>
					<b>WE BELIEVE</b> in one God who exists in three distinct persons: Father, Son and Holy Spirit.
				</li>
				<li>
					<b>WE BELIEVE</b> the entire Bible is the Word of God, inspired by the Holy Spirit, without error and the authority on which 
					we base our faith, conduct and doctrine.
				</li>
				<li>
					<b>WE BELIEVE</b> in the Baptism of Holy Spirit, to represents the death of Christ, the resurrection and to live again with Christ.
				</li>
				<li>
					<b>WE BELIEVE</b> in the taking of Holy Communion as an act of remembering the sacrifice, the death, the resurrection and 
					the second Coming of Jesus Christ.
				</li>
				<li>
					<b>WE BELIEVE</b> that the forgiveness of sin and the human salvation is God's gift through faith in Jesus Christ and 
					His work of salvation on the cross.
				</li>
				<li>
					<b>WE BELIEVE</b> that Jesus Christ is the one and only path of physical and spiritual salvation, the real truth and eternal life.
				</li>
			</ul>
		</div>
