<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","corevalues");
?>
		<div id="content">
			<h1><a href="corevalues" title="Core Values">Core Values</a></h1> 
			Generally, the Church of God (believers of Christ), carries out two main responsibilities, 
			namely The Great Commandment (Mark 12:30,31) and The Great Commission (Matthew 28:19,20) 
			from Christ.
			<br /><br />
			<strong>The Great Commandment</strong> in Mark 12:30,31 is written as the following:
			"<em>Love the Lord your God with all your heart and with all your soul and with all
			your mind and with all your strength." 
			The second is this: "Love your neighbor as yourself."
			There is no commandment greater than these</em>."
			<br /><br />
			<strong>The Great Commandment</strong> reminds the Church about <strong>its existence</strong>, 
			namely to serve God and our fellow human beings with love. The highest motivation in 
			Church ministry is <em>Love</em>, which relates to maintaining the integrity and unity of 
			the Body of Christ, as well as solving the problems that arise within the Church. 
			Love produces positive solutions to every problem and resolves it completely in a thorough 
			and peaceful manner. When Love starts to fade within the Church, it loses its true identity 
			of Jesus Christ and the Church becomes an ordinary social organization.
			<br /><br />
			Pelanggaran prinsip Kasih
			dalam bentuk apapun akan membuat Gereja "mati selagi hidup". Sang
			jenius Einstein mengakui bahwa "mati selagi hidup" adalah hal yang
			paling mengerikan, sehingga kita harus mencegahnya dengan cara tinggal
			dalam Kasih Allah dan memelihara KasihNya agar tetap hangat dan membara
			baik dalam ibadah kepada Tuhan maupun dalam membina hubungan dengan
			sesama manusia. <strong>The Great Commandment</strong> ini adalah barometer
			hubungan pribadi dengan Tuhan dan sesama. Tuhan mengingatkan jemaat di
			Korintus dan Efesus, bahwa tanpa Kasih semua prestasi Gereja akan
			sia-sia (1 Korintus 13:1-3; Wahyu 2:1-7). 
			<br /><br />
			Kasih memurnikan
			Gereja dari praktek-praktek politik dalam Gereja, fitnah, materialisme,
			gossip, iri hati, kebencian, dan lain-lain. Kasih memungkinkan Gereja
			bertumbuh dalam atmosfir sukacita dan damai sejahtera yang sehat,
			dinamis, dan supra natural, sehingga pertumbuhannya tak terbatas,
			hadirat Tuhan nyata, ibadah dan pelayanannya penuh mujizat.
			<br /><br />
			<strong>The Great Commission</strong> is written in Matthew 28:19,20 as the following:
			"<em>Therefore go and make disciples of all nations, baptizing them in the name of the Father 
			and of the Son and of the Holy Spirit, 20 and teaching them to obey everything I have 
			commanded you. And surely I am with you always, to the very end of the age.</em>"
			<br /><br />
			<strong>The Great Commission</strong> menetapkan <strong>sasaran akhir</strong> 
			untuk setiap kegiatan Gereja, yaitu <em>jiwa-jiwa terhilang diselamatkan</em>. 
			Makin tinggi sasaran <em>jiwa</em> yang ditetapkan, makin tinggi pula "harga" 
			yang harus dibayar untuk mencapainya. Tanpa penetapan sasaran jiwa, Gereja akan 
			terjebak pada rutinitas  kegiatan sehari-hari, sehingga tanpa sadar <em>kegiatan</em> 
			menjadi sasaran pelayanannya. 
			<br /><br />
			Gereja yang demikian akan tetap berjalan dengan kegiatan rutinnya, tetap
			dengan slogan "selamatkan jiwa", tapi tidak misioner. Tetap eksis, tapi
			tidak berfungsi sebagai kepanjangan tangan Tuhan untuk menyelamatkan
			jiwa-jiwa terhilang. Gereja yang tidak misioner, akan mudah terseret
			pada jerat materialisme dan kecenderungan membangun kerajaannya sendiri
			(yang seharusnya membangun Kerajaan Allah). Gereja yang demikian telah
			menyia-nyiakan Karya Keselamatan Kristus bagi dunia ini. Sebab itu
			keberhasilan pelayanan Gereja tidak diukur dari berapa banyak keuangan,
			asset atau fasilitas yang dimilikinya, tetapi dari <em>pertumbuhan kualitas rohani</em> 
			dan <em>kuantitas jemaat</em>
			yang berasal dari jiwa-jiwa terhilang yang berhasil dijangkaunya.
			Contoh gereja yang sukses saat ini ada di China, meskipun mereka tidak
			memiliki gedung gereja dan berbakti di hutan-hutan, gua-gua, dsb
			sebagai "underground church", tapi tiap hari ada 60,000 orang percaya
			dan terima Yesus sebagai Juru Selamat.
			<br /><br />
			Disamping menetapkan sasaran jiwa, Tuhan juga mengajarkan <strong>pola kerja</strong>
			untuk mencapai sasaran tersebut, yaitu dengan "menjala" manusia. Dalam
			Injil Matius 4:19 Yesus berkata kepada murid-muridNya: "<em>Mari, ikutlah Aku, dan kamu 
			akan Kujadikan penjala  manusia</em>." <strong>Jala</strong> sering diinterpretasikan 
			sebagai <em>net-work</em> (jaringan
			kerja)di antara sesama Tubuh Kristus yang terikat dan rapi
			tersusundalam semua bagian pelayanannya (Efesus 4:16). Tuhan tidak
			mengenal adanya "super star" atau "one man show" dalam Gereja karena
			semua bagian anggota Tubuh Kristus harus terlibat dalam pelayanan
			sesuai fungsinya masing-masing. Karena itu keberhasilan Gereja adalah
			keberhasilan bersama dari seluruh JemaatNya karena dipimpin oleh
			Kristus Sang Kepala Gereja.
			<br /><br />
			Untuk menjalin network, kita harus mampu bekerja secara <strong>team-work</strong>. 
			Prinsip dasar dalam team work adalah "<em>sama-sama kerja</em> supaya <em>sama-sama ringan</em>". 
			Dalam kerja team work, tidak boleh ada yang merasa "superior" sebab tidak ada
			anggota team yang dapat berfungsi tanpa ditopang oleh fungsi anggota
			team lainnya. Team-work yang efektif selalu berorientasi pada <em>hasil  kerja</em>
			(end results ). Anggota team dapat bekerja dengan fleksibel sesuai
			dengan waktu, talenta, dan gaya  masing-masing namun tetap pada arah
			sasaran yang telah ditetapkan. Team work yang demikian akan dinamis dan
			produktif<em>, </em>pelayanan berjalan baik dan jiwa-jiwa dimenangkan !
			Meskipun orientasinya pada hasil kerja, team-work yang efektif tidak
			mengabaikan <em>proses</em> (cara kerja) dalam mencapai hasil
			tersebut. Efektivitas dijaga dengan terus mengevaluasi proses yang
			telah dilakukan sehingga dapat dilakukan perbaikan-perbaikan untuk
			meningkatkan hasilnya. Untuk mengevaluasi efektivitas ini, kita semua
			harus sepakat untuk tidak menunjuk "siapa yang salah", karena hal ini
			hanya akan melukai orang lain. Sebaiknya kita harus bertanya "apa yang
			salah", maka kita akan berusaha menemukan masalahnya dan sekaligus
			memperbaikinya, dan meningkatkan apa yang sudah dianggap "baik".
			<br /><br />
			Ketika masing-masing anggota team bekerja dan melakukan fungsinya, bisa saja
			terjadi "pergesekan". Pergesekan dalam kerja itu "sehat", karena
			menunjukkan adanya semangat untuk bertanggung jawab serta keinginan
			untuk maju. Ibarat mobil yang berjalan maju dengan pesat, maka
			pergesekan antara ban mobil dengan jalan dan udara yang dilaluinya juga
			akan makin besar. Pergesekan menjadi "tidak sehat" bila motivasinya
			ingin menjatuhkan orang lain demi kepentingan pribadi dan insecurity
			(cemburu melihat keberhasilan orang lain karena dianggap sebagai
			ancaman terhadap kenyamanan kedudukannya). Karena itu, saling
			menghargai fungsi dan kerja orang lain akan membuat sukses kerja sama
			kita bersifat jangka panjang.
			<br /><br />
			Kerja sama atau net-working di antara sesama Tubuh Kristus adalah pola Alkitabiah yang sudah terbukti <em>efektif</em>
			untuk melakukan Amanat Agung. Lewat net-working ini Gereja dihindarkan
			dari kesombongan rohani dan disadarkan bahwa Tubuh Kristus itu saling
			membutuhkan dan saling melengkapi. Net-working juga dapat menjadi alat
			Tuhan untuk membangun <em>karakter</em> rendah hati dan <em>kesatuan</em> Gereja, karena kita dapat  belajar dari keunggulan maupun kekurangan orang lain. 
			<br /><br />
			<strong>Kesatuan</strong>
			adalah kata kunci dalam net-working. Kesatuan ibarat bahan bakar yang
			menggerakkan masing-masing potensi Tubuh Kristus sehingga dapat saling
			melengkapi. Segala bentuk pertikaian dan perpecahan dalam Gereja adalah
			bukti keberhasilan roh pemecah untuk mengalihkan perhatian Gereja dari
			pencapaian Amanat Agung yang mulia kepada pemuasan kedagingan yang rendah. 
			<br /><br />
			Kalau Gereja ingin melakukan Amanat Agung, tidak
			ada pola kerja yang lebih terpercaya dan efektif selain net-working,
			baik di antara jemaat dalam satu organisasi Gereja maupun dengan
			organisasi yang lain, karena pada hakekatnya semua Gereja adalah  rekan sekerja Tuhan dalam memenangkan jiwa-jiwa terhilang. 
			<br /><br />
		</div>
