<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","strategy");
?>
		<div id="content">
			<h1><a href="strategy" title="Strategy">The Strategy</a></h1>
			<b>CLC is</b> The Church of Jesus Christ who obeying <b>The Great Commission</b>
			<br /><br />
			<b>Mat.28:19,20
			<br />
			"<em>Therefore go and teach all nations, baptizing them in the name of the Father and of the Son and of the Holy Spirit, teaching them to observe all things, whatever I commanded you. And, behold, I am with you all the days until the end of the world. Amen</em>".
			</b>
			<br /><br />
			So, the strategy has been set up effectively to develop congregation's spiritual life and move them for fulfilling the Great Commission
			<br />
			<ul>
				<li>
					<b>Mobilise the congregation</b> rather than employing the full timers
				</li>
				<li>
					<b>Develop</b> the congregation <b>to grow</b> in spirit
				</li>
				<li>
					Create a <b>"ministry system"</b> that <b>effectively suits their needs</b> in each level and age
				</li>
				<li>
					Involve them to the ministry and train them <b>to be skillful in ministry</b>
				</li>
				<li>
					Send them out to <b>the mission fields</b>
				</li>
			</ul>
			<br />
			<h2>The Ministry</h2>
			CLC is applying a "simple" ministry system. The system should be <b>effective to develop congregation's spiritual lives</b>:
			<ul>
				<li>
					With <b>specific ministry</b> upon each <b>level</b> and <b>age</b>
				</li>
				<li>
					To achieve <b>measurable spiritual target</b> that necessary for each level to grow to the "next" level as more "mature" and responsible church members
				</li>
				<li>
					To involve them <b>in church ministry</b> complying with their calling, talents and God’s gifts 
				</li>
				<li>
					To mobilise them <b>in synergy</b> for fulfilling the <a href="visionmission">vision-mission</a> of the church
				</li>
			</ul>
			<br />
			<h2>How to do the system?</h2>
			<ul>
				<li>
					The congregation are asked to fill in a questionnaire for identifying their level. They are  classified into <b>3 levels</b>
				</li>
				<li>
					The purpose of this classification is <b>to give effective and specific ministries</b> to each level complying with their spiritual needs 
				</li>
				<li>
					Then some <b>measurable spiritual targets</b> of each level should be achieved in order to grow to the next level
				</li>
				<li>
					Each level of congregation will be involved into ministries and mission works <b>complying with</b> their spiritual growth
				</li>
			</ul>
			<br />
			<h2><a href="strategy" title="Strategy">The classification</a></h2>
			CLC is The Church of Love &amp; Compassion who
			<ul>
				<li>Reaching the un-reachable</li>
				<li>Touching the un-touchable</li>
				<li>Loving the un-lovable</li>
			</ul>
			<br /><br />
			<h2><strong>1st Level of <font color="#FF0000">C</font>LC<br /><font color="#FF0000">C</font> = <font color="#FF0000">C</font>hrist is personal saviour</strong></h2>
			<ul>
				<li>
					Regardless any spiritual background of the congregation, they will be served up until they know Jesus Christ as personal saviour.
				</li>
				<li>
					<b>The targets of this level:</b>
					<ul>
						<li>
							<b>Salvation</b> of the congregation by the grace of God
						</li>
						<li>
							<b>Transformation</b> of the congregation to become "born again Christians"
						</li>
						<li>
							<b>Understand</b> basic Christianity principles <b>to become responsible church members</b>
						</li>
					</ul>
				</li>
			</ul>
			<br /><br />
			<h2><strong>2nd Level of C<font color="#FF0000">L</font>C<br /><font color="#FF0000">L</font> = <font color="#FF0000">L</font>ove God, <font color="#FF0000">L</font>ove The Church</strong></h2>
			<ul>
				<li>
					The congregation should be disciples that able to practice their love to God by serving His church
				</li>
				<li>
					<b>The targets of this level:</b>
					<ul>
						<li>
							<b>Involvement</b> of the congregation in at least ONE church ministry (may be more) complying with their talents, gifts and God's calling
						</li>
					</ul>
				</li>
			</ul>
			<br /><br />
			<h2><strong>3rd Level of CL<font color="#FF0000">C</font><br /><font color="#FF0000">C</font> = <font color="#FF0000">C</font>ompassion to the world
			</strong></h2>
			<ul>
				<li>
					The maturity of the congregation’s love to God should be developed not only to the church but also to the world.
				</li>
				<li>
					They have to fulfill God’s highest calling in their lives by reaching out the world for Jesus (to do God's mission)
				</li>
				<li>
					<b>The targets of this level:</b>
					<ul>
						<li>
							<b>Equiping and training</b> the congregation in theology, leadership and ministry skill training
						</li>
						<li>
							<b>Sending out</b> ONE congregation to bring ONE person in ONE year to the church (1-1-1 mission project)
						</li>
						<li>
							<b>Helping and preparing</b> the congregation to fulfill God's highest calling in their lives as evangelist, missionary, preacher, leaders, etc
						</li>
					</ul>
				</li>
			</ul>
		</div>