<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","history");
?>
		<div id="content">
			<div id="pastormsg">
				<p class="greeting"><b>Welcome brothers &amp; sisters in Christ,</b></p>
				<p>I believe as we do His Words faithfully then God, who is faithful to
				keep His Words, will make this year our best year so far.</p>
				<p>Let us pray and serve together as part of body of Christ and a big
				loving family through His precious redemption.</p>
			</div>
			<h1><a href="history" title="History">History</a></h1> 
			<b>Christ Living Church, the church with love and compassion</b>
			<br />
			CLC started the first service on 18 June 2006 at 10.00 am, using School of Art building, Peakhurst NSW. 
			The first service was attended by approx 30 people (included children). After the service, whilst we were having lunch together, out of the blue, 
			there was an aircraft flying high, exactly above the building and crafting two written smokes in the sky such as "Trust in Jesus alone" and "Jesus saves".
			<br /><br />
			<a href="http://www.christlivingchurch.com/home/gallery.html?album=message-in-the-sky">
				<img src="http://www.christlivingchurch.com/home/clc_files/images/sejarah_clc_trustinjesusalone.jpg" alt="Trust in Jesus alone" class="floatleft" />
			</a>At that time, in my heart, I knew that God used those two "signs" in the sky to send a message that He confirmed the ministry of CLC and also 
			gave His anointing and blessings upon His beloved congregation. 
			A few months later, I felt that God won’t let us occupy that small building more than one year, so I announced it to the congregation that 
			we would occupy the building up until our first anniversary. 
			<br /><br />
			We were so happy, because we felt God’s presence in our dynamic and powerful Sunday services. Lots of miracles happened among the congregation. 
			The church members were united as a Christ family and one accord. They were helping each other and doing the ministries with full of happiness, 
			even though we have to load and unload our music instruments and sound equipments every Sunday. 
			God sent lots of new multicultural church goers, but also screened some people away from the church. Lots of lives have been changed drastically.
			<br /><br />
			<a href="http://www.christlivingchurch.com/home/gallery.html?album=first-sunday-service-in-st-paul-anglican-kogarah">
				<img src="http://www.christlivingchurch.com/home/clc_files/images/sejarah_clc_kogarah.jpg" alt="CLC 1st Sunday Serv9ce in Kogarah" class="floatright" />
			</a>In one year, God made the church grew up until 50-60 people. We had 100% church growth. The building became too small for the church, 
			so we started to seek another building with bigger capacity. God was so great! He fulfilled what He had put in my heart by providing a beautiful 
			building for His church. A week after celebrating our first anniversary in Sunday service on 17 June 2007, 
			then we moved to Hall of St. Paul’s Anglican Church, Kogarah NSW. CLC continued the ministry in this new place since 24 June 2007. 
			God bless us in this place and makes us growing more in quality and quantity of the congregation and ministries.    
			<br /><br />
			Even though initially CLC's organization is different, but from the beginning CLC has been accepted and treated like a "family member" by 
			St. Paul's congregation. CLC has been supported very much by St. Paul's church, 
			especially by providing lots of facilities for the ministries. Along the existence in St. Paul’s church complex, 
			CLC has also been cooperating and hand in hand with St. Paul's congregation in ministries and activities, 
			included in some church projects' developments. God is really blessing CLC very much in this place. 
			Based on our Annual General Meeting’s report on December 2010, 
			the average weekly attendances of our Sunday Service for last year were 125 – 150 people. 
			Praise God, all the glory is just for Him.  
			<br /><br />
			<a href="http://www.christlivingchurch.com/home/gallery.html?album=clc-become-st-pauls-anglican-member-ceremony">
				<img src="http://www.christlivingchurch.com/home/clc_files/images/sejarah_clc_stpaulmember.jpg" alt="CLC and St Paul Church Anglican" class="floatleft" />
			</a>Actually, CLC has been offered to become St. Paul's church member for a quite long time. However, after considering the offer 
			for more than one year, eventually, CLC decided to gladly receive it based on the autonomously principles which is mutual respecting 
			and acknowledging the authority of each other communities. Therefore, commencing from 15 March 2009, officially, 
			CLC becomes a family member of St. Paul’s Anglican Church, equal with the other existed congregations in the organization. 
			This membership is for the sake of the unity of The Body of Christ and purposely to achieve His Church’s goals which is reaching out 
			the lost souls in all over the world and broadening the ministries for the benefits of multicultural communities through all over Australia. 
			<br /><br />
			This membership is not changing any principles in CLC such as: doctrine, liturgy, financial, management, leadership, etc. 
			Praise God for all of St. Paul's existed congregations that accepting CLC as a new member in the family. 
			Under the grace of God, through this unity, all of us have been empowered to do more effective ministries and productive mission to 
			the world. It's proven now! Through the internet technology, CLC's Information Technology team are developing a very effective website 
			which is being accessed by people in all over the world.
			<br /><br />
			From this website, they may be streaming and <a href="http://www.christlivingchurch.com/sermon">watching the sermon video</a>, 
			<a href="http://www.christlivingchurch.com/home/sermon-audio-podcasts.html">downloading the mp3 audio sermons into computer</a>, 
			<a href="http://www.christlivingchurch.com/home/prayer.html#prayerrequest">submitting the prayer requests</a>, enjoying 
			<a href="http://www.christlivingchurch.com/home/gallery.html">the photo gallery</a>, etc. Also, since year 2009 our Sunday Service 
			has been live broadcasted through internet to all over the world. 
			Therefore, even though CLC is a local church with limited local congregation, but has global impact with unlimited global congregation. 
			Some global  ministry invitations are coming from South Africa, India, Philippines, Vietnam, Thailand, China, Hongkong, Myanmar, 
			Indonesia, etc. Some of churches in those countries asked CLC to be their partner in ministry and mission. 
			One church in Thailand is asking CLC to cover their ministry as a sister church for God's glory.  
			<br /><br />
			His story in CLC has begun and will be continued more spectacular in the future to come. Amen!
			<br /><br /><br />
			In the blessings of Jesus Christ,
			<br /><br />
			<b><u>Ir. Agus Rahardja DS, MA Mis.</u></b>
			<br /><br />
			Senior Pastor of Christ Living Church
		</div>
