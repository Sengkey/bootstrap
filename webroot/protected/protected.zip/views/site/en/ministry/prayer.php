<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","prayer");
?>
		<div id="content">
			<h1><a href="prayer" title="Prayer Ministry">Prayer Ministry</a></h1>
			In Christ Living Church, we believe in the power of prayer either to support the ministry or every aspects of our daily life. Prayer is the essence of our relationship with God, as it is the way for us to connect and communicate with God. Prayer is God's gift to us.
			<br /><br />
			<a name="prayermeeting"></a>
			<h2><a href="prayer#prayermeeting" title="Prayer Meeting">Prayer Meeting</a></h2>
			We believe that the prayer meeting was a central part of church life, an indispensable part of the ministries. Prayer is a powerful "tool" for breakingthrough your problem and a gate to receive  Heaven's blessing abundantly. So, don't ever miss our prayer meeting which is held on:
			<br /><br />
			<ul>
				<li>
					<b>Date:</b> Every Saturdays, 0430pm - except the 5th week of the month
				</li>
				<li>
					<b>Location:</b> 57 Princes Hwy, Kogarah
				</li>
			</ul>
			<br />
			<a name="prayerrequest"></a>
			<h2><a href="prayer#prayerrequest" title="Prayer Request">Prayer Request</a></h2>
			We accept your prayer requests especially if you have any problems or anything to be supported in our prayer meeting. We will keep you in our prayer.
			<br />Let's experience healings and miracles with us.
			<br />Enjoy your victorious life by the grace of God in Jesus Christ The Lord.
			<br /><br />
			<hr /> 
			<br /> 
			<strong>Note:</strong> Please provide us with the detailed information about the subject to pray.
			<br /><br /> 
			<strong>Not-much-detailed information example:</strong> Please pray for my problem
			<br /><br /> 
			<strong>Detailed information example:</strong> Please support me in prayer as I am currently suffering from backpain, and I have to lead a worship for the first time next week.
			<br /><br /> 
			<hr />
			<br />

<div class="ce_form block">
	<form action="prayer" id="f1" method="post" enctype="application/x-www-form-urlencoded">
	<div class="formbody">
	<table cellspacing="0" cellpadding="0" summary="Form fields">
		<tr class="row_0 row_first even">
			<td class="col_0 col_first"><label for="ctrl_1">Title:</label></td>
			<td class="col_1 col_last"><select name="Title" id="ctrl_1" class="select"><option value="Mr.">Mr.</option><option value="Mrs.">Mrs.</option><option value="Miss">Miss</option></select></td>
		</tr>
		<tr class="row_1 odd">
			<td class="col_0 col_first"><label for="ctrl_2" class="mandatory">First Name:</label><span class="mandatory">*</span></td>
			<td class="col_1 col_last"><input type="text" name="First_Name" id="ctrl_2" class="text mandatory" value="" maxlength="15" /></td>
		</tr>
		<tr class="row_2 even">
			<td class="col_0 col_first"><label for="ctrl_3" class="mandatory">Last Name:</label><span class="mandatory">*</span></td>
			<td class="col_1 col_last"><input type="text" name="Last_Name" id="ctrl_3" class="text mandatory" value="" maxlength="15" /></td>
		</tr>
		<tr class="row_3 odd">
			<td class="col_0 col_first"><label for="ctrl_4" class="email mandatory">Email Address:</label><span class="mandatory">*</span></td>
			<td class="col_1 col_last"><input type="text" name="Email_Address" id="ctrl_4" class="text email mandatory" value="" /></td>
		</tr>
		<tr class="row_4 even">
			<td class="col_0 col_first"><label for="ctrl_6" class="mandatory">Content</label><span class="mandatory">*</span></td>
			<td class="col_1 col_last"><textarea name="Comments" id="ctrl_6" class="textarea mandatory" rows="8" cols="40"></textarea></td>
		</tr>
		<tr class="row_5 row_last odd">
			<td class="col_0 col_first"><label for="ctrl_7">Security Question:</label><span class="mandatory">*</span></td>
			<td class="col_1 col_last"><input type="text" name="cf38fb090c0c0617316a4c061cd16cdc4" id="ctrl_7" class="captcha" value="0" maxlength="2" /> <input type="submit" id="ctrl_7_submit" class="submit" value="Submit" /> <span class="captcha_text">What is the sum of 5 and 9?</span></td>
		</tr>
	</table>
	</div>
	</form>
</div>
			<br /><br />
			<blockquote class="verse">
				Do not be anxious about anything, but in every situation, by prayer and petition, with thanksgiving, present your requests to God. 
				And the peace of God, which transcends all understanding, will guard your hearts and your minds in Christ Jesus.
				<br />- Philippians 4:6-7
			</blockquote>
		</div>
