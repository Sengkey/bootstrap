<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","foodbeverage");
?>
		<div id="content">
			<h1><a href="foodbeverage" title="Food and Beverage Ministry">Food & Beverage Ministry</a></h1>
			<div class="ministryimg"><img src="<?=Yii::app()->request->getBaseUrl(true)?>/images/ministry/foodbeverage.jpg" /></div>The mission of the Food and Beverage Ministry is to share the love of Jesus Christ by caring not only the spiritual needs but also 
			the practical needs of the church.
			<br /><br />
			This ministry is responsible for preparing the meals for our activities, such as services, 
			<a href="./discipleship-training">Bible study classes</a> and any other special events. We are also available to help with your 
			wedding reception or rehearsal dinner.
			<br /><br />
			<a name="voluntary"></a>
			<h2><a href="foodbeverage#voluntary" title="Voluntary">Volunteer Opportunities</a></h2> 
			We are now recruiting volunteers with the following requirements:
			<ul>
				<li>
					must have a personal relationship with Jesus Christ
				</li>
				<li>
					must attend Christ Living Church on a regular basis
				</li>
				<li>
					must have the heart to serve others
				</li>
				<li>
					must be have a passion to learn about cooking
				</li>
			</ul>
			<b><em>» Training is provided</em></b>
			<br /><br />
			<div class="contact">If you are interested, feel free to 
				<a href="mailto:admin@christlivingchurch.com?subject=I%20am%20interested%20to%20join%20CLC%20Food%20Beverage%20Team">contact us 
					by email here</a>
			</div>
			<br /><br />
			<blockquote class="verse">
			Remove far from me falsehood and lying; give me neither poverty nor riches; feed me with the food that is needful for me<br />- Proverbs 30:8 (ESV)
			</blockquote>
		</div>
