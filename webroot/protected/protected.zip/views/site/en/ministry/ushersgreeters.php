<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","ushersgreeters");
?>
		<div id="content">
			<h1><a href="ushersgreeters" title="Ushers & Greeters Ministry">Ushers & Greeters Ministry</a></h1>
			Ushers are forerunners, for they are the first who meet the people coming to church who are sometimes burdened, sad or discouraged. 
			The usher greets them with a pleasant smile, a warm welcome and escort them to comfortable seats. This ministry is crucial because it 
			ensures that people see and experience God's love before the service starts.
			<br /><br />
			<a name="roles"></a>
			<h2><a href="ushersgreeters#roles" title="Roles">Roles</a></h2>
			<ul>
				<li>
					greet people, making every attempt to help them to feel welcome and at ease
				</li>
				<li>
					direct the people to their seats
				</li>
				<li>
					distribute materials related to CLC (bulletin, welcome card, information card, etc.)
				</li>
				<li>
					deliver the offerings to the congregations
				</li>
				<li>
					dealing with any emergencies that may arise, or contacting the person(s) needed to provide the proper assistance
				</li>
			</ul>
			<br /><br />
			<a name="voluntary"></a>
			<h2><a href="ushersgreeters#voluntary" title="Voluntary">Volunteer Opportunities</a></h2> 
			<br />
			We are now recruiting volunteers with the following requirements:
			<ul>
				<li>
					must have a personal relationship with Jesus Christ
				</li>
				<li>
					must attend Christ Living Church on a regular basis
				</li>
				<li>
					must have a humble heart to serve Him
				</li>
			</ul>
			<b><em>» Training is provided</em></b>
			<br /><br />
			<div class="contactbyphone">If you are interested, feel free to contact <br />Steven Heniwan in 0413971592 or Yuli 0423339553</div>
			<br /><br />
			<blockquote class="verse">
				Praise the Lord, all you servants of the Lord who minister by night in the house of the Lord
				<br />- Psalm 134:1
			</blockquote>
		</div>
