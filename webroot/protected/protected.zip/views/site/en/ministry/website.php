<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","website");
?>
		<div id="content">
			<h1><a href="website" title="Website Ministry">Website Ministry</a></h1>
			At Christ Living Church, we believe in using the Internet to reach out to spread the Good News as well as to connect with people. 
			The main objectives of having this website are:
			<ul>
				<li>
					To help people who are looking for a home church
				</li>
				<li>
					To help people finding out which ministries and activities in CLC available to them
				</li>
				<li>
					To help people growing spiritually by providing additional complementing resources to the services and ministries such as 
					free online video sermon, notes, devotional and many more
				</li>
			</ul>
			<br />
			<a name="voluntary"></a>
			<h2><a href="website#voluntary" title="Voluntary">Volunteer Opportunities</a></h2> 
			We are now recruiting volunteers with the following requirements:
			<ul>
				<li>
					must have a personal relationship with Jesus Christ
				</li>
				<li>
					must attend Christ Living Church on a regular basis
				</li>
				<li>
					must be at least 16 years old
				</li>
				<li>
					must have a passion in learning web development and designing
				</li>
			</ul>
			<b><em>» Training is provided</em></b>
			<br /><br />
			<div class="contact">If you are interested, feel free to 
				<a href="mailto:admin@christlivingchurch.com?subject=I%20am%20interested%20to%20join%20CLC%20Website%20Team">contact us 
					by email here</a>
			</div>
		</div>
