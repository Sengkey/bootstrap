<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","stagedesign");
?>
		<div id="content">
			<h1><a href="stagedesign" title="Stage Design Ministry">Stage Design Ministry</a></h1>
			<div class="ministryimg"><img src="<?=Yii::app()->request->getBaseUrl(true)?>/images/ministry/stagedesign.jpg" /></div>The Stage, Lighting and Decoration Ministry provide stage & event lighting and stage decorations for minor and major 
			Christ Living Church events. We are one team who shares the same passion and uses our creativity to combine stage decorations 
			and natural & artificial light into a symphony of the visual arts capable of communicating the timeless message of the Gospel 
			to every member of Christ Living Church.
			<br /><br />
			<a name="voluntary"></a>
			<h2><a href="stagedesign#voluntary" title="Voluntary">Volunteer Opportunities</a></h2> 
			We are now recruiting volunteers with the following requirements:
			<ul>
				<li>
					must have a personal relationship with Jesus Christ
				</li>
				<li>
					must attend Christ Living Church on a regular basis
				</li>
				<li>
					must have passion to design, art and colours
				</li>
				<li>
					must be creative, lively, enthusiastic and ORIGINAL!!!
				</li>
			</ul>
			<b><em>» Training is provided</em></b>
			<br /><br />

			<div class="contact">If you are one of those talented and gifted people and are interested in joining The Stage, Lighting and 
				Decoration Ministry, please do not hesitate to 
				<a href="mailto:stagedesign@clc.asn.au?subject=I%20am%20interested%20to%20join%20CLC%20Stage%20Design%20Team">contact us</a> 
				and together we will make Christ Living Church a more colourful and fun church to go to!!!
			</div>
			<br /><br />
			<blockquote class="verse">
				The temple I am going to build will be great, because our God is greater than all other gods. But who is able to build a 
				temple for him, since the heavens, even the highest heavens, cannot contain him? Who then am I to build a temple for him, 
				except as a place to burn sacrifices before him? Send me, therefore, a man skilled to work in gold and silver, bronze and iron, 
				and in purple, crimson and blue yarn, and experienced in the art of engraving, to work in Judah and Jerusalem with my skilled 
				workers, whom my father David provided
				<br />- 2 Chronicles 2:5-7
			</blockquote>
		</div>
