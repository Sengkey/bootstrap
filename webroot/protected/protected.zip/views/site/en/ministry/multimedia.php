<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","multimedia");
?>
		<div id="content">
			<h1><a href="multimedia" title="Multimedia Ministry">Multimedia Ministry</a></h1>
			CLC Multimedia Team started their ministry since the beginning Sunday Service of CLC at Peakhurst, NSW. This team is simply built 
			to serve God with our all talents such as in IT background, design and multimedia stuffs. People working in this team have to give 
			all the best their skills to create a great convenient in every events of serving our Lord especially on Sunday Service. This will 
			aim that attract people who still do not know God then bring them into the throne of God.
			<br /><br />
			<a name="roles"></a>
			<h2><a href="multimedia#roles" title="Roles">Roles</a></h2>
			<ul>
				<li>
					<b>Sunday Services Operator</b>
					<br />
					This role is used for preparing the songs lyric, operate the multimedia tools and present them up in front of others people every Sunday. 
					Songs lyric is prepared in two languages as usual such as Indonesian and English.
				</li>
				<li>
					<b>Publication</b>
					<br />
					This role is used to give what sort of activities we have in church during the weekdays and normally its purpose is to attract others to 
					join them by giving a good presentation layout through out the paper similar to invitation called "Warta". Inside it, there are plenty 
					good articles about Christianity and daily bread of each week.
				</li>
				<li>
					<b>Creative and Video Team</b>
					<br />
					This role is team-based to handle creativity and talents in serving God such as making drama performance and church news.
				</li>
			</ul>
			<br />
			<a name="voluntary"></a>
			<h2><a href="multimedia#voluntary" title="Voluntary">Volunteer Opportunities</a></h2> 
			We are now recruiting volunteers with the following requirements:
			<ul>
				<li>
					must have a personal relationship with Jesus Christ
				</li>
				<li>
					must attend Christ Living Church on a regular basis
				</li>
			</ul>
			<b><em>» Training is provided</em></b>
			<br /><br />
			<div class="contact">If you are interested, feel free to 
				<a href="mailto:multimedia@christlivingchurch.com?subject=I%20am%20interested%20to%20join%20CLC%20Multimedia%20Team">contact us 
					by email here</a>
			</div>
			<br /><br />
			<blockquote class="verse">
				Not with eye-service, as men-pleasers, but as the servants of Christ, doing the will of God from the heart,  with good will doing 
				service as to the Lord and not to men
				<br />- Ephesians 6:6-7 (KJV)
			</blockquote>
		</div>
