<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","library");
?>
		<div id="content">
			<h1><a href="library" title="Library Ministry">Library Ministry</a></h1>
			<div class="ministryimg"><img src="<?=Yii::app()->request->getBaseUrl(true)?>/images/ministry/library.jpg" /></div>CLC Library operates as a repository of knowledge and information, with the help of some donations it is certainly growing and 
			expanding in its collection of resources quite steadily. We would like to thank all the donors who have helped made it grow.
			<br /><br />
			We have now successfully made it as a repository and access point for print, audio, and visual materials in numerous formats, 
			including maps, books, documents, audio tapes / cassettes, CDs, videotapes, DVDs for mostly spiritual (based on Christian belief) and 
			some additional of non spiritual resources such as books on cooking recipes, home interior decorations, etc.
			<br /><br />
			Unlike the usual quiet library in a quiet room, we have an unusual happy market atmosphere library setup in the busy church hall. 
			You will have fun being there serving or choosing the resources you need to borrow.
			<br /><br />
			Donors are welcome to donate any good useful resources to help the Library to expand its collection as fast as it could. The type of 
			resources could be books, audio tapes / cassettes, CDs, videotapes, DVDs. 
			<br /><br />
			<a name="roles"></a>
			<h2><a href="library#roles" title="Roles">Roles</a></h2>
			<ul>
				<li>
					To provide friendly helpful services and useful resources which support the achievement in helping the congregation to grow spiritually, and to gain more knowledge, skills, and abilities to improve their quality of life.
				</li>
				<li>
					To hold and lend out books or other type of resources for set periods of time so it is helping people who choose not to, or cannot afford to purchase an extensive collection themselves.
				</li>
				<li>
					To encourage congregation to read more books.
				</li>
				<li>
					To build good and closer relations among the congregation who serve within the Library Ministry and the congregation who borrow the resources.
				</li>
				<li>
					To learn practicing good team work and aiming for excellent team work within the congregation who serve within the Library Ministry.
				</li>
			</ul>
			<br />
			<a name="voluntary"></a>
			<h2><a href="library#voluntary" title="Voluntary">Volunteer Opportunities</a></h2> 
			We are now recruiting volunteers with the following requirements:
			<ul>
				<li>
					must have a personal relationship with Jesus Christ
				</li>
				<li>
					must attend Christ Living Church on a regular basis
				</li>
				<li>
					must have a good, happy, friendly, helpful personality
				</li>
				<li>
					like to serve others 
				</li>
				<li>
					(optional) have a neat and good hand writing     
				</li>
			</ul>
			<b><em>» Training is provided</em></b>
			<br /><br />
			<div class="contact">For volunteering and or giving donations you may please contact us by email to: 
				<a href="mailto:admin@christlivingchurch.com?subject=About%20the%20CLC%20Library%20Ministry">contact us by email here</a>
			</div>
		</div>
