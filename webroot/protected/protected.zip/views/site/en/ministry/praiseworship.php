<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","praiseworship");
?>
		<div id="content">
			<h1><a href="praiseworship" title="Praise and Worship Ministry">Praise and Worship Ministry</a></h1>
			<div class="ministryimg"><img src="<?=Yii::app()->request->getBaseUrl(true)?>/images/ministry/praiseworship-singers.jpg" /></div>
			CLC Worship Team started their ministry since the very beginning CLC Sunday service at Peakhurst NSW. CLC Worship Team is simply a 
			team of vocalists and musicians who loves God and loves people. We use our gifts, talents and God-given abilities during our worship 
			services. The ultimate goal of our ministry is to bring people to the throne of God, invite the presence of the Holy Spirit and to 
			experience the dynamic worship atmosphere to the church.
			<br /><br />
			In December 2008, CLC Worship Team was known as Rise Up Music Ministry. We are committed to providing worship excellence. As a new 
			initiative, we also have created and prepared resources at our website 
			<a href="http://www.riseupmusic.com" target="_blank">www.riseupmusic.com</a> where you can find information about CLC Praise and Worship, 
			to learn more about our music, head coordinators, team leaders and various opportunities for you in our vocal and music department.
			<br /><br />
			We believe that this department will be even more anointed and empowered to deliver spirit of excellence in every worship sessions, 
			committed to the team, to do the best and be blessings for congregations by the grace of God.
			<br /><br />
			<a name="roles"></a>
			<h2><a href="praiseworship#roles" title="Roles">Roles</a></h2>
			<ul>
				<li>
					<b>Vocalists</b>
					<br />
					This role is for people who have experience in singing, especially on the stage. If you are able to sing harmony by ear and/or 
					can sing solo when needed, this role is perfect for you.
					<br />
					<b><em>» Training is provided</em></b>
					<br /><br />
					<div class="contact">If you are interested in serving in this capacity, please contact Selly at 
						<a href="mailto:music@clc.asn.au?subject=I%20am%20interested%20to%20join%20CLC%20Vocalists%20Team">music@clc.asn.au</a>; 
						Auditions are required.
					</div>
					<br />
				</li>
				<li>
					<b>Musicians</b>
					<div class="ministryimg"><img src="<?=Yii::app()->request->getBaseUrl(true)?>/images/ministry/praiseworship-drum.jpg" /></div>
					<br />
					This role is for you who have experience in playing variety of musical instruments. You will need to demonstrate adequate talent 
					in the area of music. Apart from playing your musical instrument based on chords and sheet music, playing by ear (hearing skills) 
					is also highly recommended. Use and develop the gifts and talents God has given you. You will need to continuously developing your 
					musical skills and techniques outside the team's rehearsal time. However, please note that CLC Worship Team requires not only a 
					high level of musical skill but also the highest level of commitment.
					<br />
					<b><em>» Training is provided</em></b>
					<br /><br />
					<div class="contact">If you are interested in serving in this capacity, please contact riF at 
						<a href="mailto:music@clc.asn.au?subject=I%20am%20interested%20to%20join%20CLC%20Musicians%20Team">music@clc.asn.au</a>; 
						Auditions are required.
					</div>
					<br />
				</li>
				<li>
					<b>Choir Team</b>
					<br />
					The choirs are open to anyone that loves to sing. We often have choirs for our yearly events.
					<br />
					<b><em>» Training is provided</em></b>
					<br /><br />
					<div class="contact">Please contact 
						<a href="mailto:music@clc.asn.au?subject=I%20am%20interested%20to%20join%20CLC%20Choir%20Team">music@clc.asn.au</a> to find 
						out if there is a choir opportunity for CLC upcoming events; No auditions necessary.
					</div>
				</li>
			</ul>
			<br /><br />
			<blockquote class="verse">
				Sing to Him a new song; play skillfully and shout for joy
				<br />- Psalm 33:3
			</blockquote>
		</div>
