<?php 
$this->pageTitle=Yii::app()->name;
Yii::app()->clientScript->registerLinkTag("canonical","","soundsystem");
?>
		<div id="content">
			<h1><a href="soundsystem" title="Sound System Ministry">Sound System Ministry</a></h1>
			<div class="ministryimg"><img src="<?=Yii::app()->request->getBaseUrl(true)?>/images/ministry/soundsystem.jpg" /></div>The Sound System Team of Christ Living Church exists to glorify the Lord Jesus Christ by providing quality sound services to our speakers, 
			vocalists and music team, so that every message in the word or song would be clearly heard and understood.
			<br /><br />
			It is essential to have a solid sound reinforcement, as almost majority of the ministries in CLC is involved with audio. Worship leaders, 
			singers, choir and speakers need to produce a good level of sound through the speakers to give more impact to congregation. 
			In addition, we need sound reinforcement to ensure every single person in the building able to hear every word clearly spoken by CLC 
			speakers. We believe in a maximum spirit of excellence to our Sound Ministry. Providing the expertise in an attitude of joy and patience.
			<br /><br />
			<a name="roles"></a>
			<h2><a href="soundsystem#roles" title="Roles">Roles</a></h2>
			<ul>
				<li>
					<b>Sound Technician</b>
					<br />
					This is the entry-level role into Sound Ministry. This person is responsible to ensure that each microphone is correctly setup, 
					plugged into the right place in the multicore and sound board. To ensure all microphone cables are neat. If the need arises, 
					the Sound Technician is the person who moves mics and stands during a service to facilitate the best sound pick up with 
					the least amount of intrusion or interruption to the service. The Sound Technician is also responsible for testing, identification 
					and repair or replacement of faulty cables, as directed by the Sound Engineer. Sound Technician also requires 
					to have "an ear to hear", after all, the way it sounds is the bottom line!
					<br /><br />
					<div class="contact">If you are interested in serving in this capacity, please 
						<a href="mailto:worship@clc.asn.au?subject=I%20am%20interested%20to%20join%20CLC%20Sound%20Team">contact us by email here</a>
					</div>
					<br />
				</li>
				<li>
					<b>Sound Engineer</b>
					<br />
					The Sound Engineer is a person who has demonstrated competency in types of equipment in a sound system and its functions, 
					how the components of a sound system work together to best present the sound to the hearers, what frequency response of a room 
					has to do with the settings of the equpments, how to troubleshoot various sound problems through acoustical treatments, EQ, 
					speaker placements and more. This role is also responsible for the training and all quality control of the ministry. 
					Evaluate the performance of the system in weekly basis, correcting any problems and adjusting the acoustic design if necessary.
					<br /><br />
					<div class="contact">If you are interested in serving in this capacity, please 
						<a href="mailto:worship@clc.asn.au?subject=I%20am%20interested%20to%20join%20CLC%20Sound%20Team">contact us by email here</a>
					</div>
				</li>
			</ul>
		</div>
