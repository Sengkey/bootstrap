<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<title><?php echo CHtml::encode($this->pageTitle); ?></title>
	<meta name="language" content="en" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="shortcut icon" href="http://www.christlivingchurch.com/home/favicon.ico">
	<link rel="shortcut icon" href="http://www.christlivingchurch.com/home/favicon.gif" type="image/gif">
	<meta name="robots" content="nofollow" />

	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->getBaseUrl(true); ?>/css/style.css" />

	<!--[if lt IE 8]>
	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->getBaseUrl(true); ?>/css/ie.css" media="screen, projection" />
	<![endif]-->
	<script type='text/javascript' src='<?=Yii::app()->request->getBaseUrl(true)?>/js/jquery.js'></script>
	<script type='text/javascript' src='<?=Yii::app()->request->getBaseUrl(true)?>/js/jquery.cycle.all.js'></script>
	<script type='text/javascript' src='<?=Yii::app()->request->getBaseUrl(true)?>/js/countdown.js'></script>
<!--
	<script type="text/javascript">
		window.___gcfg = {lang: 'en'};
		(function() 
		{var po = document.createElement("script");
		po.type = "text/javascript"; po.async = true;po.src = "https://apis.google.com/js/plusone.js";
		var s = document.getElementsByTagName("script")[0];
		s.parentNode.insertBefore(po, s);
		})();
	</script>
-->
</head>

<body>
		<?=$content?>
</body>
</html>