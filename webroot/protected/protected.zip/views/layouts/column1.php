<?php $this->beginContent('//layouts/main'); ?>
<?=$content?>
<?php $this->endContent(); ?>